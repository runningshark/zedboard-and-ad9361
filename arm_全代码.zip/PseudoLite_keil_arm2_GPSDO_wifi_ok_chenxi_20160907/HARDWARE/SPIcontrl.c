#include "stm32f4xx_gpio.h"
#include "stm32f4xx_spi.h"
#include "ads1282.h"
#include "stm32f4xx_usart.h"
//double toshowgraphic[1000];
long int __attribute__((section(".array"))) graphic_1[500];
long int __attribute__((section(".array"))) graphic_2[500];
long int __attribute__((section(".array"))) graphic_3[500];

void MySPI_SendData(char da);
uint16_t MySPI_ReceiveData(void);

unsigned int temp = 0x00;
unsigned int tempx;

void testSPI()
{
	unsigned char temp_read1;
	unsigned char temp_read2;
	unsigned char temp_read3;
	unsigned char temp_read4;
	unsigned long int temp_read_U;
	signed long int temp_read_S;
	
	if(!DRDY_ADC)
	{
		
		MySPI_SendData(0x00);
		temp_read1 = MySPI_ReceiveData();

		
		SPI_SendData(SPI2,0x00);
		temp_read2 = MySPI_ReceiveData();

		
		MySPI_SendData(0x00);
		temp_read3 = MySPI_ReceiveData();

		MySPI_SendData(0x00);
		temp_read4 = MySPI_ReceiveData();


		temp_read_U = 0x00000000;
		temp_read_U += temp_read1;
		temp_read_U <<= 8;
		temp_read_U += temp_read2;
		temp_read_U <<= 8;
		temp_read_U += temp_read3;
		temp_read_U <<= 8;
		temp_read_U += temp_read4;
		
		temp_read_S = temp_read_U;
		if(temp)
			tempx = temp - 1;
		else
			tempx = 499;

		graphic_1[temp] = temp_read_S;
		{
			long int a;
			a = graphic_1[temp];
			graphic_2[temp] = a;
		}
		//graphic_2[temp] = temp_read_S;
		graphic_3[temp] = graphic_3[tempx]*0.95+temp_read_S*0.05;
		//graphic[temp] = fist_order_lag_Filter(graphic_s[tempx],graphic_s[temp]);
		//toshowgraphic[temp] = toshowgraphic[tempx] + 1;
		USART_SendData(USART1, graphic_3[temp]); //�����յ�������
		temp++;
		if(temp > 499)
			temp = 0;
	}
}
