#ifndef __RADAR_XILINX_H
#define __RADAR_XILINX_H
#include "stm32f4xx_fsmc.h"

void GPIO_FSMC_Init(void);
void FSMC_init(void);
void select_spi_port(uint8_t port);
void ad9361_hardware_initial(void);
#define FPGA_ADDRESS 0x60000000
#define FPGA_read(offset) *((volatile unsigned short int *)(FPGA_ADDRESS +(offset<<1)))
#define FPGA_write(offset,data) *((volatile unsigned short int *)(FPGA_ADDRESS +(offset<<1)))=(unsigned short int)data;	

#define SPI_AD9361 0
#define SPI_GPS 1
#define SPI_BD 2
#define SPI_NONE 3

#endif

