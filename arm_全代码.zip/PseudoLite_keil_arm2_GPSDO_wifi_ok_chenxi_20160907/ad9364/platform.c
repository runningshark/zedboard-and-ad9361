/***************************************************************************//**
 *   @file   Platform.c
 *   @brief  Implementation of Platform Driver.
 *   @author DBogdan (dragos.bogdan@analog.com)
********************************************************************************
 * Copyright 2013(c) Analog Devices, Inc.
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *  - Neither the name of Analog Devices, Inc. nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *  - The use of this software may or may not infringe the patent rights
 *    of one or more patent holders.  This license does not release you
 *    from the requirement that you obtain separate licenses from these
 *    patent holders to use this software.
 *  - Use of the software either in source or binary form, must be run
 *    on or directly connected to an Analog Devices Inc. component.
 *
 * THIS SOFTWARE IS PROVIDED BY ANALOG DEVICES "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, NON-INFRINGEMENT,
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL ANALOG DEVICES BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, INTELLECTUAL PROPERTY RIGHTS, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*******************************************************************************/

/******************************************************************************/
/***************************** Include Files **********************************/
/******************************************************************************/
#include "stm32f4xx.h" 
#include "ctype.h"
#include "stdint.h"
#include "util.h"
#include "platform.h"
#define SPI2ASAD9361_CONFIG

/***************************************************************************//**
 * @brief usleep
*******************************************************************************/
//wangfei
/*
static __inline void usleep(unsigned long usleep)
{

}
*/
/***************************************************************************//**
 * @brief spi_init   û���õ�
*******************************************************************************/
int32_t spi_init(uint32_t device_id,
				 uint8_t  clk_pha,
				 uint8_t  clk_pol)
{
	return 0;
}

/***************************************************************************//**
 * @brief spi_read  �Ѿ���ֲ
*******************************************************************************/
int32_t spi_read(uint8_t *data,uint8_t bytes_number)
{
    uint8_t tx_buf[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint8_t rx_buf[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint8_t index;
#ifdef SPI2ASAD9361_CONFIG
		SPI_Cmd(SPI2, ENABLE); //Enable SPI2
		GPIO_ResetBits(GPIOB, GPIO_Pin_12); //NSS LOW
		SPI_I2S_SendData(SPI2, data[0]); //write the first data
		if(bytes_number>1)
		{
			  for(index = 1; index < bytes_number; index++)
				{
						tx_buf[index] = data[index];
						while(RESET==SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_TXE))
						{
							;
						}
						SPI_I2S_SendData(SPI2, tx_buf[index]);
						while(RESET==SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_RXNE))
						{
							;
						}		
						rx_buf[index-1] = SPI_I2S_ReceiveData(SPI2);	
				}	
				while(RESET==SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_RXNE))
				{
						;
				}		
				rx_buf[index-1] = SPI_I2S_ReceiveData(SPI2);	
		}
		else
		{
					while(RESET==SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_RXNE))
					{
						;
					}		
					rx_buf[0] = SPI_I2S_ReceiveData(SPI2);					
		}
		while(RESET==SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_TXE))
		{
			;
		}		
		while(SET==SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_BSY))
		{
			;
		}	
		GPIO_SetBits(GPIOB, GPIO_Pin_12);
		SPI_Cmd(SPI2, DISABLE); //Disable SPI2
    for(index = 0; index < bytes_number; index++)
		{
    	data[index] = rx_buf[index];			
		}
		return 0;
#else		
		SPI_Cmd(SPI1, ENABLE); //Enable SPI2
		GPIO_ResetBits(GPIOA, GPIO_Pin_8); //NSS LOW
		SPI_I2S_SendData(SPI1, data[0]); //write the first data
		if(bytes_number>1)
		{
			  for(index = 1; index < bytes_number; index++)
				{
						tx_buf[index] = data[index];
						while(RESET==SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_TXE))
						{
							;
						}
						SPI_I2S_SendData(SPI1, tx_buf[index]);
						while(RESET==SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_RXNE))
						{
							;
						}		
						rx_buf[index-1] = SPI_I2S_ReceiveData(SPI1);	
				}	
				while(RESET==SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_RXNE))
				{
						;
				}		
				rx_buf[index-1] = SPI_I2S_ReceiveData(SPI1);	
		}
		else
		{
					while(RESET==SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_RXNE))
					{
						;
					}		
					rx_buf[0] = SPI_I2S_ReceiveData(SPI1);					
		}
		while(RESET==SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_TXE))
		{
			;
		}		
		while(SET==SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_BSY))
		{
			;
		}	
		GPIO_SetBits(GPIOA, GPIO_Pin_8);
		SPI_Cmd(SPI1, DISABLE); //Disable SPI2
    for(index = 0; index < bytes_number; index++)
		{
    	data[index] = rx_buf[index];			
		}
		return 0;
#endif
}

/***************************************************************************//**
 * @brief spi_write_then_read      �Ѿ���ֲ
*******************************************************************************/
int spi_write_then_read(struct spi_device *spi,
		const unsigned char *txbuf, unsigned n_tx,
		unsigned char *rxbuf, unsigned n_rx)
{
	uint8_t buffer[20] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
						  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
						  0x00, 0x00, 0x00, 0x00};
	uint8_t byte;

	for(byte = 0; byte < n_tx; byte++)
	{
		buffer[byte] = (unsigned char)txbuf[byte];
	}
	spi_read(buffer, n_tx + n_rx);
	for(byte = n_tx; byte < n_tx + n_rx; byte++)
	{
		rxbuf[byte - n_tx] = buffer[byte];
	}

	return SUCCESS;
}

/***************************************************************************//**
 * @brief gpio_init     û���õ�
*******************************************************************************/
void gpio_init(uint32_t device_id)
{

}

/***************************************************************************//**
 * @brief gpio_direction û���õ�
*******************************************************************************/
void gpio_direction(uint8_t pin, uint8_t direction)
{

}

/***************************************************************************//**
 * @brief gpio_is_valid  �Ѿ���ֲ  ���������ad9361_mcs�������õ���
 �������ж�����һ��GPIO�ܽ��Ƿ���Ч������ͳһ��������Ч��
*******************************************************************************/
bool gpio_is_valid(int number)
{
	switch (number){
		case 0: return true;
		case 1: return false;
		case 2: return false;
		case 3: return false;	
	}
	//return 1; //wangfei ǿ��ʹ��GPIO��λAD9364
	//return 0;
}

/***************************************************************************//**
 * @brief gpio_data
*******************************************************************************/
void gpio_data(uint8_t pin, uint8_t data)
{

}

/***************************************************************************//**
 * @brief gpio_set_value  ad9361_mcs�������õ��ˣ���û������
*******************************************************************************/
void gpio_set_value(unsigned gpio, int value)
{

}

/***************************************************************************//**
 * @brief udelay   �Ѿ���ֲ
*******************************************************************************/
void udelay(unsigned long usecs)
{
	 //stm32f10X ??72MHz,1~100us?? */    
   u16 i=0;  
	 if(usecs>100)
	 {
			usecs=100;
	 }
   for(i=usecs*9;i>0;i--)
	 {
			;
	 }
}

/***************************************************************************//**
 * @brief mdelay   �Ѿ���ֲ
*******************************************************************************/
void mdelay(unsigned long msecs)
{
//stm32f10X ??72MHz,1~1000ms??   
		u32 i;
		if(msecs>1000)
		{
			msecs=1000;
		}
		for(i=msecs*12000;i>0;i--)
		{
				;
		}
}

/***************************************************************************//**
 * @brief msleep_interruptible    û���õ�
*******************************************************************************/
unsigned long msleep_interruptible(unsigned int msecs)
{

	return 0;
}

/***************************************************************************//**
 * @brief axiadc_init	ad9361_init��ad9361_set_no_ch_mode�������õ���
 �������ʼ�����ֽӿڲ��ֵģ������Ǻ�ad9361�Խӵ�fpga���ֵ�
 �²�Ӧ���ǶԵģ���������������adc��ʼ����dac��ʼ�������������ֱ�
 ��fpga�Ķ�Ӧ���ֽӿڲ��ֽ����˳�ʼ��
*******************************************************************************/
void axiadc_init(struct ad9361_rf_phy *phy)
{

}

/***************************************************************************//**
 * @brief axiadc_read
*******************************************************************************/
unsigned int axiadc_read(struct axiadc_state *st, unsigned long reg)
{
	return 0;
}

/***************************************************************************//**
 * @brief axiadc_write  ad9364.c���õ��ܶ�
*******************************************************************************/
void axiadc_write(struct axiadc_state *st, unsigned reg, unsigned val)
{

}

/***************************************************************************//**
* @brief axiadc_set_pnsel ����ad9361_dig_tune���õ�
*******************************************************************************/
int axiadc_set_pnsel(struct axiadc_state *st, int channel, enum adc_pn_sel sel)
{
	return 0;
}
