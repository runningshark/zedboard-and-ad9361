#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stm32f4xx.h>
#include <delay.h>
#include <math.h>
#include "stm32f4_discovery.h"
#include "radar_xilinx.h"
#include "pseudolite.h"
#include "code.h"
uint32_t bch_encode(uint32_t *inbuf, uint32_t* outbuf, uint32_t length)
{
	return 0;
}
uint32_t bch_decode(uint32_t *inbuf, uint32_t* outbuf, uint32_t length)
{
	return 0;
}
bool set_tx_amplititude(uint16_t v)
{
	if(v<=0x7ff)
	{
		FPGA_write(TX_DATA_AMPLITUDE_ADDR,v);
		return true;
	}
	else
	{
		FPGA_write(TX_DATA_AMPLITUDE_ADDR,0x7ff);
		return false;
	}
}
bool is_one_pps_available(void)
{
	uint16_t data=FPGA_read(BUSY_PAGE_INDEX_ADDR);
	if((data&0x0008)!=0x0000)
	{
		return true;
	}
	else 
	{
		return false;
	}
}
bool is_tx_sending(void)
{
	uint16_t data=FPGA_read(BUSY_PAGE_INDEX_ADDR);
	if((data&0x0004)!=0x0000)
	{
		return true;
	}
	else 
	{
		return false;
	}
}
uint16_t busy_page(void)
{
	uint16_t data=FPGA_read(BUSY_PAGE_INDEX_ADDR);
	return (data&0x3);
}
uint32_t get_onepps_interval(void)
{
	uint16_t dataL=FPGA_read(ONEPPS_INTERVAL_LOW_ADDR);
	uint16_t dataH=FPGA_read(ONEPPS_INTERVAL_HIGH_ADDR);
	uint32_t data=(dataH<<16);
	data=data+dataL;
	return data;
}
uint32_t set_cycles(uint32_t interval)
{
	uint16_t cycles=interval/2046000;
	uint32_t remain = interval % 2046000;
	FPGA_write(CYCLES_PER_BIT_ADDR,cycles);
	FPGA_write(CYCLES_LEFT_LOW_ADDR,remain&0xFFFF);
	FPGA_write(CYCLES_LEFT_HIGH_ADDR,(uint16_t)(remain>>16));
	return 0;
}
bool set_page(uint16_t page, bool freerun_mode)
{
	uint16_t data=0;
	if(page>1) return false;
	if (freerun_mode == true)
	{
		data = 2;
	}
	FPGA_write(PSEUDOLITE_CTRL_ADDR, page|(data));
	return true;
}
bool set_sv_number(uint16_t sv)
{
  int i=0;
  short* code_pointer;
	if(sv>37) 
	{
		return false;
	}
  if(sv<5)
  {
    switch(sv)
    {
				case  1  : code_pointer = code1;break;
				case  2  : code_pointer = code2;break;
				case  3  : code_pointer = code3;break;
				case  4  : code_pointer = code4;break;
				case  5  : code_pointer = code5;break;
				case  6  : code_pointer = code6;break;
				case  7  : code_pointer = code7;break;
				case  8  : code_pointer = code8;break;
				case  9  : code_pointer = code9;break;
				case  10  : code_pointer = code10;break;
				case  11  : code_pointer = code11;break;
				case  12  : code_pointer = code12;break;
				case  13  : code_pointer = code13;break;
				case  14  : code_pointer = code14;break;
				case  15  : code_pointer = code15;break;
				case  16  : code_pointer = code16;break;
				case  17  : code_pointer = code17;break;
				case  18  : code_pointer = code18;break;
				case  19  : code_pointer = code19;break;
				case  20  : code_pointer = code20;break;
				case  21  : code_pointer = code21;break;
				case  22  : code_pointer = code22;break;
				case  23  : code_pointer = code23;break;
				case  24  : code_pointer = code24;break;
				case  25  : code_pointer = code25;break;
				case  26  : code_pointer = code26;break;
				case  27  : code_pointer = code27;break;
				case  28  : code_pointer = code28;break;
				case  29  : code_pointer = code29;break;
				case  30  : code_pointer = code30;break;
				case  31  : code_pointer = code31;break;
				case  32  : code_pointer = code32;break;
				case  33  : code_pointer = code33;break;
				case  34  : code_pointer = code34;break;
				case  35  : code_pointer = code35;break;
				case  36  : code_pointer = code36;break;
				case  37  : code_pointer = code37;break;
				case  38  : code_pointer = code38;break;
				case  39  : code_pointer = code39;break;
				case  40  : code_pointer = code40;break;
				case  41  : code_pointer = code41;break;
				case  42  : code_pointer = code42;break;
				case  43  : code_pointer = code43;break;
				case  44  : code_pointer = code44;break;
				case  45  : code_pointer = code45;break;
				case  46  : code_pointer = code46;break;
				case  47  : code_pointer = code47;break;
				case  48  : code_pointer = code48;break;
				case  49  : code_pointer = code49;break;
				case  50  : code_pointer = code50;break;
				case  51  : code_pointer = code51;break;
				case  52  : code_pointer = code52;break;
				case  53  : code_pointer = code53;break;
				case  54  : code_pointer = code54;break;
				case  55  : code_pointer = code55;break;
				case  56  : code_pointer = code56;break;
				case  57  : code_pointer = code57;break;
				case  58  : code_pointer = code58;break;
				case  59  : code_pointer = code59;break;
				case  60  : code_pointer = code60;break;
				case  61  : code_pointer = code61;break;
				case  62  : code_pointer = code62;break;
				case  63  : code_pointer = code63;break;
				case  64  : code_pointer = code64;break;
				case  65  : code_pointer = code65;break;
				case  66  : code_pointer = code66;break;
				case  67  : code_pointer = code67;break;
				case  68  : code_pointer = code68;break;
				case  69  : code_pointer = code69;break;
				case  70  : code_pointer = code70;break;
				case  71  : code_pointer = code71;break;
				case  72  : code_pointer = code72;break;
				case  73  : code_pointer = code73;break;
				case  74  : code_pointer = code74;break;
				case  75  : code_pointer = code75;break;
				case  76  : code_pointer = code76;break;
				case  77  : code_pointer = code77;break;
				case  78  : code_pointer = code78;break;
				case  79  : code_pointer = code79;break;
				case  80  : code_pointer = code80;break;
				case  81  : code_pointer = code81;break;
				case  82  : code_pointer = code82;break;
				case  83  : code_pointer = code83;break;
				case  84  : code_pointer = code84;break;
				case  85  : code_pointer = code85;break;
				case  86  : code_pointer = code86;break;
				case  87  : code_pointer = code87;break;
				case  88  : code_pointer = code88;break;
				case  89  : code_pointer = code89;break;
				case  90  : code_pointer = code90;break;
				case  91  : code_pointer = code91;break;
				case  92  : code_pointer = code92;break;
				case  93  : code_pointer = code93;break;
				case  94  : code_pointer = code94;break;
				case  95  : code_pointer = code95;break;
				case  96  : code_pointer = code96;break;
				case  97  : code_pointer = code97;break;
				case  98  : code_pointer = code98;break;
				case  99  : code_pointer = code99;break;
				case  100  : code_pointer = code100;break;
				case  101  : code_pointer = code101;break;
				case  102  : code_pointer = code102;break;
				case  103  : code_pointer = code103;break;
				case  104  : code_pointer = code104;break;
				case  105  : code_pointer = code105;break;
				case  106  : code_pointer = code106;break;
				case  107  : code_pointer = code107;break;
				case  108  : code_pointer = code108;break;
				case  109  : code_pointer = code109;break;
				case  110  : code_pointer = code110;break;
				case  111  : code_pointer = code111;break;
				case  112  : code_pointer = code112;break;
				case  113  : code_pointer = code113;break;
				case  114  : code_pointer = code114;break;
				case  115  : code_pointer = code115;break;
				case  116  : code_pointer = code116;break;
				case  117  : code_pointer = code117;break;
				case  118  : code_pointer = code118;break;
				case  119  : code_pointer = code119;break;
				case  120  : code_pointer = code120;break;
				case  121  : code_pointer = code121;break;
				case  122  : code_pointer = code122;break;
				case  123  : code_pointer = code123;break;
				case  124  : code_pointer = code124;break;
				case  125  : code_pointer = code125;break;
				case  126  : code_pointer = code126;break;
				case  127  : code_pointer = code127;break;
				case  128  : code_pointer = code128;break;

       default:break;
     }
    for(i=0;i<128;i++)
    {
       FPGA_write(CODR_RAM_START+i,code_pointer[i]);
    }
  }
	FPGA_write(SV_NUMBER_ADDR,sv);
	return true;
}
bool set_page_data(uint32_t *buf, uint32_t length, uint16_t page_index)
{
	int i;
	int page_start=0;
	if(page_index>1) 
	{return false;}
	if(length!=10)
	{return false;}
	page_start=(page_index==0)?TXDATA_PAGE0_START:TXDATA_PAGE1_START;
	for(i=0;i<length;i++)
	{
		FPGA_write(page_start+i*2+1,buf[i]&0xFFFF);
		FPGA_write(page_start+i*2,(buf[i]>>16));
	}
	return true;
}
bool pseudolite_ctrl(bool tx_ena,bool ublox_ena, bool arm_uart2_rx_ublox_data)
{
	uint16_t data;
	data=FPGA_read(RF_CTRL_ADDR);
	data=data&0x3F;
	if(tx_ena==true) data=data|MAIN_RF_TX_ENA|MAIN_RF_RX_ENA;
	if(true==ublox_ena) data=data|UBLOX_RX_ENA;
	if(arm_uart2_rx_ublox_data==true) data=data|ARM_UART2_HAS_UBLOXDATA;
	FPGA_write(RF_CTRL_ADDR,data);
	return true;
}
bool pseudolite_init(uint16_t sv)
{
	bool ret;
	ret=set_sv_number(sv);
	if(ret==false) return ret;
	ret=set_tx_amplititude(0x1ff);
	if(ret==false) return ret;
	ret=pseudolite_ctrl(true,true,false);
	return ret;
}
bool reset_gps(void)
{
FPGA_write(UBLOX_RESETN_ADDR,0);
delay_ms(20);
FPGA_write(UBLOX_RESETN_ADDR,1);	
	 return true;
}

/*wang jiabo */
/*define the AT commands in ASCII*/
uint8_t esp_rst[8]={'A','T','+','R','S','T',0x0D,0X0A};
uint8_t esp_mod[13]={'A','T','+','C','W','M','O','D','E','=','2',0x0D,0X0A};
uint8_t esp_swsap[34]={'A','T','+','C','W','S','A','P','=','"','E','S','P','"',',','"','0','1','2','3','4','5','6','7','8','9','"',',','1','1',',','0',0x0D,0X0A};
uint8_t esp_cipmux[13]={'A','T','+','C','I','P','M','U','X','=','1',0x0D,0X0A};
uint8_t esp_cipserver[21]={'A','T','+','C','I','P','S','E','R','V','E','R','=','1',',','8','0','8','0',0x0D,0X0A};
uint8_t esp_cipstatus[14]={'A','T','+','C','I','P','S','T','A','T','U','S',0x0D,0X0A};
uint8_t esp_cipsend[16]={'A','T','+','C','I','P','S','E','N','D','=','0',',','6',0x0D,0X0A};
uint8_t esp_bytesend[6]={'E','S','P','W','I','F'};

/*initialize the esp8266*/
void esp8266_init()
{
	uint8_t *pointer = esp_rst;
	uint8_t i=0;
	
	FPGA_write(WIFI_CTRL,0x0);//reset esp8266
	delay_ms(1000);//1s
	FPGA_write(WIFI_CTRL,0x1);
	delay_ms(2000);//2s
	
  for(i=0;i<8;i++)//esp_rst command
	{
		USART_SendData(UART4, *(pointer++));
		while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
	}
	delay_ms(1000);//wait for response from ESP8266
	pointer = esp_mod;
	for(i=0;i<13;i++)//set AP mode
	{
		USART_SendData(UART4, *(pointer++));
		while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
	}
	delay_ms(1000);
	pointer = esp_rst;
	for(i=0;i<8;i++)//rest after setting AP mode
	{
		USART_SendData(UART4, *(pointer++));
		while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
	}
	delay_ms(1000);
	pointer = esp_swsap;
	for(i=0;i<34;i++)//set AP parameter
	{
		USART_SendData(UART4, *(pointer++));
		while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
	}
	delay_ms(1000);
	pointer = esp_cipmux;
	for(i=0;i<13;i++)//enable multi link
	{
		USART_SendData(UART4, *(pointer++));
		while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
	}
	delay_ms(1000);
	pointer = esp_cipserver;
	for(i=0;i<21;i++)// setup the server
	{
		USART_SendData(UART4, *(pointer++));
		while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
	}
	delay_ms(1000);
//	pointer = esp_cipstatus;// check the cipstatus
//	for(i=0;i<14;i++)
//	{
//		USART_SendData(UART4, *(pointer++));
//		while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
//	}
//	delay_ms(1000);
//	pointer = esp_cipsend;
//	for(i=0;i<16;i++)//cipsend
//	{
//		USART_SendData(UART4, *(pointer++));
//		while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
//	}
//	delay_ms(1000);
//	pointer = esp_bytesend;
//		for(i=0;i<6;i++)//send bytes
//	{
//		USART_SendData(UART4, *(pointer++));
//		while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
//	}
//	delay_ms(1000);
}
	
/*
���ߣ�֣�ɹ�
��������Bch_encoder(uint32_t *inbuf, uint32_t *outbuf, uint32_t length)
������������������ָ�룬������������ָ�룬�������鳤��
���ܣ���inbuf�е����ݽ���BCH���벢����outbuf��*/
uint32_t G[BCH_N] = {1024,512,256,128,64,32,16,8,4,2,1,1964,982,491,1881};
uint32_t Bch_encoder(uint32_t *inbuf, uint32_t *outbuf, uint32_t length)
{ 
    uint32_t Subword1data,Subword0data,Subword;
    uint32_t i = 0, j = 0, k = 0, Sum0 = 0, Sum1 = 0, Parity0 = 0, Parity1 = 0;

    for (i = 0; i < length; i++)
    {
        Subword = 0;
        Subword0data = *(inbuf + i) & 0x000007FF;
        Subword1data = (*(inbuf + i) & 0x003FF800) >> 11;

        for (j = 0; j < BCH_N; j++)
        {
            Sum0 = Subword0data & G[j];
            Sum1 = Subword1data & G[j];
            Parity0 = 0;
            Parity1 = 0;
            for (k = 0; k < BCH_K; k++)
            {
                if (Sum0 & 1)
                {
                    Parity0++;
                }
                Sum0 = Sum0 >> 1;
                if (Sum1 & 1)
                {
                    Parity1++;
                }
                Sum1 = Sum1 >> 1;
            }
            Parity0 = Parity0 & 0x1;
            Parity1 = Parity1 & 0x1;
            Subword = Subword | (Parity0 << (14 - j));
            Subword = Subword | (Parity1 << (15 + 14 - j));
        }
        *(outbuf + i) = Subword;
    }
    return (0);
}

/*
���ߣ�֣�ɹ�
��������Bch_decoder(uint32_t *inbuf, uint32_t *outbuf, uint32_t length)
������������������ָ�룬������������ָ�룬�������鳤��
���ܣ���inbuf�е����ݽ���BCH���벢����outbuf��*/
uint32_t HT[BCH_R] = {31432,15716,7858,30097};
uint32_t H[BCH_N] = {9,13,15,14,7,10,5,11,12,6,3,8,4,2,1};
uint32_t Bch_decoder(uint32_t *inbuf, uint32_t *outbuf, uint32_t length)
{
    
    uint32_t Subword1,Subword0,Subworddata;
    uint32_t s0,s1;
    uint32_t errorbit0,errorbit1,errorflag0,errorflag1,i = 0, j = 0, n = 0, Sum0 = 0, Sum1 = 0, Parity0 = 0, Parity1 = 0;

    for (i = 0; i < length; i++)
    {
        Subworddata = 0;
        Subword0 = *(inbuf + i) & 0x00007FFF;
        Subword1 = (*(inbuf + i) & 0x3FFF8000) >> 15;

        s0 = 0;
        s1 = 0;
        for (j = 0; j < BCH_R; j++)
        {
            Sum0 = Subword0 & HT[j];
            Sum1 = Subword1 & HT[j];
            Parity0 = 0;
            Parity1 = 0;
            for (n = 0; n < BCH_N; n++)
            {
                if (Sum0 & 1)
                {
                    Parity0++;
                }
                Sum0 = Sum0 >> 1;
                if (Sum1 & 1)
                {
                    Parity1++;
                }
                Sum1 = Sum1 >> 1;
            }
            Parity0 = Parity0 & 0x1;
            Parity1 = Parity1 & 0x1;
            s0 = s0 | (Parity0 << (BCH_R - 1 - j));
            s1 = s1 | (Parity1 << (BCH_R - 1 - j));
        }

        if (s0 == 0)
        {
            errorflag0 = 0;
        }
        else
        {
            for (j = 0; j < BCH_N; j++)
            {
                if ((s0 == H[j]))
                {
                    errorbit0 = BCH_N - 1 - j;
                    Subword0 = Subword0 ^ (0x0001 << errorbit0);
                    errorflag0 = 1;
                }
            }
        }

        if (s1 == 0)
        {
            errorflag1 = 0;
        }
        else
        {
            for (j = 0; j < BCH_N; j++)
            {
                if (s1 == H[j])
                {
                    errorbit1 = BCH_N - 1 - j;
                    Subword1 = Subword1 ^ (0x0001 << errorbit1);
                    errorflag1 = 1;
                }
            }
        }
        Subworddata = (Subword0 >> 4) | Subworddata;
        Subworddata = ((Subword1 >> 4) << 11) | Subworddata;

        *(outbuf + i) = Subworddata;
    }
    return (0);
}

/*
���ߣ������
��������NavSol_Send(struct PVTSending *p)
������ָ���������Ϣ�ṹ���ָ��
���ܣ�����������Ϣ���ϳ�ָ���ĸ�ʽ������BCH���벢ѡ����ʵ�page*/
uint32_t Parity = 0;
uint32_t ID = 0;
void NavSol_Send(struct PVTSending *p, bool freerun_mode)
{
	uint32_t i, outtemp, parity = 0, *outbuf, *EncodeOutbuf;
	uint16_t pageindex;
	outbuf[0] = ((p->WN & 0x00001c00) >> 10) | ID | Preamble;
	outbuf[1] = ((p->WN & 0x000003ff) << 12) | ((p->SoW & 0x000fff00) >> 8);
	outbuf[2] = (p->SoW & 0x000000ff << 14) | ((p->ecefX & 0xfffc0000) >> 18);
	outbuf[3] = ((p->ecefX & 0x0003ffff) << 4) | ((p->ecefY & 0xf0000000) >> 28);
	outbuf[4] = p->ecefY & 0x0fffffc0 >> 3;
	outbuf[5] = ((p->ecefY & 0x0000003f) << 16) | ((p->ecefZ & 0xffff0000) >> 16);
	outbuf[6] = ((p->ecefZ & 0x0000ffff) << 6) | ((p->ecefVX & 0x00fc0000) >> 18);
	outbuf[7] = ((p->ecefVX & 0x0003ffff) << 4) | ((p->ecefVY & 0x00f00000) >> 20);
	outbuf[8] = ((p->ecefVY & 0x000fffff) << 2) | ((p->ecefVZ & 0x00c00000) >> 22);
	outbuf[9] = p->ecefVZ & 0x003fffff;
	
	for (i = 0; i < 10; i++)
	{
		outtemp = outbuf[i];
		while (outtemp)
		{
			parity = !parity;
			outtemp = outtemp & (outtemp - 1);
		}
		Parity = Parity | (parity << (i + 9));
	}
	outbuf[0] = outbuf[0] | Parity;
	
	Bch_encoder(outbuf, EncodeOutbuf, 10);
	pageindex = (busy_page() == 0x0001 || busy_page() == 0x0003) ? 0 : 1;
	set_page_data(EncodeOutbuf, 10, pageindex);
	set_page(pageindex, freerun_mode);
}

/*
���ߣ������
������: GetPVTSending(struct NAVSOL_Typedef MessageIn[], struct PVTSending *MessageSend)
������ublox�����Ϣ���飬ָ���跢����Ϣ�ṹ���ָ��
���ܣ��Դ洢��6s ublox�����Ϣ�����˶�״̬��⣬Ԥ���跢����Ϣ����ת��Ϊ�跢����Ϣ�ĸ�ʽ*/
float GM = 3.986005e20, We = 7.292115e-5;
void GetPVTSending(struct NAVSOL_Typedef MessageIn[], struct PVTSending *MessageSend, uint8_t PredictingTime)
{
	int8_t MessageNum, i, MovState, Still = 0, InOrbit = 0;
	int32_t x, y, z, r, vx, vy, vz, vel, accx, accy, accz;
	for (MessageNum = 0; MessageNum < 6; MessageNum++)
	{
		vx = MessageIn[MessageNum].ecefVX;
		vy = MessageIn[MessageNum].ecefVY;
		vz = MessageIn[MessageNum].ecefVZ;
		vel = sqrt(vx*vx + vy*vy + vz*vz);
		if(vel > 100000)
			InOrbit++;
		else if(vel < 100)
			Still++;
		if (InOrbit > 3)
			MovState = 2;
		else if (Still > 3)
			MovState = 0;
		else
			MovState = 1;
	}
	switch (MovState)
	{
		case 0:
		{
			x = 0;
			y = 0;
			z = 0;
			vx = 0;
			vy = 0;
			vz = 0;
			for (MessageNum = 0; MessageNum < 6; MessageNum++)
			{
				x = x + MessageIn[MessageNum].ecefX;
				y = y + MessageIn[MessageNum].ecefY;
				z = z + MessageIn[MessageNum].ecefZ;
				vx = vx + MessageIn[MessageNum].ecefVX;
				vy = vy + MessageIn[MessageNum].ecefVY;
				vz = vz + MessageIn[MessageNum].ecefVZ;
			}
			MessageSend->ecefX = (uint32_t)(x / 6);
			MessageSend->ecefY = (uint32_t)(y / 6);
			MessageSend->ecefZ = (uint32_t)(z / 6);
			MessageSend->ecefVX = (uint32_t)(vx / 6);
			MessageSend->ecefVY = (uint32_t)(vy / 6);
			MessageSend->ecefVZ = (uint32_t)(vz / 6);
		}
		case 2:
		{
			x = MessageIn[5].ecefX;
			y = MessageIn[5].ecefY;
			z = MessageIn[5].ecefZ;
			vx = MessageIn[5].ecefVX;
			vy = MessageIn[5].ecefVY;
			vz = MessageIn[5].ecefVZ;
			for (i = 0; i < PredictingTime; i++)
			{
				r = sqrt(x*x + y*y + z*z);
				accx = -GM * x / (r * r * r) + We * We * x + 2 * We * vy;
				accy = -GM * y / (r * r * r) + We * We * y - 2 * We * vx;
				accz = -GM * z / (r * r * r);
				x = x + vx + (accx >> 1);
				y = y + vy + (accy >> 1);
				z = z + vz + (accz >> 1);
				vx = vx + accx;
				vy = vy + accy;
				vz = vz + accz;
			}		
			MessageSend->ecefX = (uint32_t)x;
			MessageSend->ecefY = (uint32_t)y;
			MessageSend->ecefZ = (uint32_t)z;
			MessageSend->ecefVX = (uint32_t)vx;
			MessageSend->ecefVY = (uint32_t)vy;
			MessageSend->ecefVZ = (uint32_t)vz;
//			for (i = 0; i < 6; i++)
//			{
//				OriginMatrix[i][i] = 1;
//			}
//			do
//			{
//			for (MessageNum = 0; MessageNum < 6; MessageNum++)
//			{
//				for (i = 0; i < 4; i++)
//				{
//					OrbitDerivatives(&MessageSend, dState[i], dStateMatrix[i], MessageNum - 6);
//				}
//				for (i = 0; i < 6; i++)
//				{
//					Predict[MessageNum * 6 + i] = OriginTemp[i] + (dState[0][i] + (dState[1][i]<<1) + (dState[2][i]<<1) + dState[3][i]) / 6;
//					for (j = 0; j < 6; j++)
//					{
//						StateMatrix[MessageNum * 6 + i][j] = OriginMatrix[i][j] + (dStateMatrix[0][i][j] + (dStateMatrix[1][i][j]<<1) + (dStateMatrix[2][i][j]<<1) + dStateMatrix[3][i][j]) / 6;
//					}
//				}
//				Err[MessageNum * 6] = MessageIn[MessageNum].ecefX - Predict[MessageNum * 6];
//				Err[MessageNum * 6 + 1] = MessageIn[MessageNum].ecefY - Predict[MessageNum * 6 + 1];
//				Err[MessageNum * 6 + 2] = MessageIn[MessageNum].ecefZ - Predict[MessageNum * 6 + 2];
//				Err[MessageNum * 6 + 3] = MessageIn[MessageNum].ecefVX - Predict[MessageNum * 6 + 3];
//				Err[MessageNum * 6 + 4] = MessageIn[MessageNum].ecefVY - Predict[MessageNum * 6 + 4];
//				Err[MessageNum * 6 + 5] = MessageIn[MessageNum].ecefVZ - Predict[MessageNum * 6 + 5];
//			}
//			dOriginTemp = MatrixDiv(StateMatrix, Err);
//			for (i = 0; i < 6; i++)
//			{
//				OriginTemp[i] = OriginTemp[i] + dOriginTemp[i];
//			}
//		}
		}
		case 1:
		{
			accx = MessageIn[5].ecefVX - MessageIn[4].ecefVX;
			accy = MessageIn[5].ecefVY - MessageIn[4].ecefVY;
			accz = MessageIn[5].ecefVZ - MessageIn[4].ecefVZ;
			MessageSend->ecefX = (uint32_t)(MessageIn[5].ecefX + MessageIn[5].ecefVX * PredictingTime + (accx >> 1) * PredictingTime * PredictingTime);
			MessageSend->ecefY = (uint32_t)(MessageIn[5].ecefY + MessageIn[5].ecefVY * PredictingTime + (accy >> 1) * PredictingTime * PredictingTime);
			MessageSend->ecefZ = (uint32_t)(MessageIn[5].ecefZ + MessageIn[5].ecefVZ * PredictingTime + (accz >> 1) * PredictingTime * PredictingTime);
			MessageSend->ecefVX = (uint32_t)(MessageIn[5].ecefVX + accx * PredictingTime);
			MessageSend->ecefVY = (uint32_t)(MessageIn[5].ecefVY + accy * PredictingTime);
			MessageSend->ecefVZ = (uint32_t)(MessageIn[5].ecefVZ + accz * PredictingTime);
		}
		default:
			break;
	}
}

uint16_t timetest = 0, weektest = 0;
void freeRunMode()
{
	struct PVTSending MessageSend;
	MessageSend.ecefX = 1;
	MessageSend.ecefY = 2;
	MessageSend.ecefZ = 3;
	MessageSend.ecefVX = 1;
	MessageSend.ecefVY = 2;
	MessageSend.ecefVZ = 3;
	MessageSend.SoW = timetest++;
	if (timetest > 100)
		MessageSend.WN = ++weektest;
	NavSol_Send(&MessageSend, true);
}