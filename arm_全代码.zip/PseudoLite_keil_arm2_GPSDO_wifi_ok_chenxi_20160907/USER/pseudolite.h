#ifndef _PSEUDOLITE_H_
#define _PSEUDOLITE_H_
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <ublox.h>
#include "common.h"
#define SYNC0_ADDR 0x0
#define SYNC1_ADDR 0x1
#define UBLOX_DATA_START 0x0
#define TXDATA_PAGE0_START 0x20
#define TXDATA_PAGE1_START 0x34
#define SV_NUMBER_ADDR 0x80
#define RF_CTRL_ADDR 0x81
#define CHECK_SELF_ADDR 0x82
#define AD9361_CTRL_IN_ADDR 0x83
#define AD9361_CTRL_OUT_ADDR 0x84
#define PSEUDOLITE_CTRL_ADDR 0x85
#define CYCLES_PER_BIT_ADDR 0x86
#define CYCLES_LEFT_HIGH_ADDR 0x87
#define CYCLES_LEFT_LOW_ADDR 0x88
#define ONEPPS_INTERVAL_LOW_ADDR 0x89
#define ONEPPS_INTERVAL_HIGH_ADDR 0x8A
#define BUSY_PAGE_INDEX_ADDR 0x8B
#define TX_DATA_AMPLITUDE_ADDR 0x8C
#define UBLOX_RESETN_ADDR 0x8D
#define ONE_PPS_GAP_LOW 0x8E
#define ONE_PPS_GAP_HIGH 0x8F
#define LOCALONEPPS_INTERVAL_LOW 0x90
#define LOCALONEPPS_INTERVAL_HIGH 0x91
#define WIFI_CTRL 0x92
#define EEPROM_SCL 0x93
#define EEPROM_SDA 0x94
#define EEPROM_SDA_ENA 0x95
#define SAMPLE_CLK_FRE_LOW 0x96
#define SAMPLE_CLK_FRE_HIGH 0x97
#define ONEPPS_OFFSET_LOW 0X98
#define ONEPPS_OFFSET_HIGH 0X99
#define DAC_REG_CTRL 0X9A
#define DAC_REG_DATA 0X9B
#define AD9361_RESET 0X9D
#define CODR_RAM_START 0x200
#define MAIN_RF_TX_ENA (1<<6)
#define MAIN_RF_RX_ENA (1<<7)
#define UBLOX_RX_ENA (1<<8)
#define ARM_UART2_HAS_UBLOXDATA (1<<9)
#define VERSION_VALUE 0x1201
#define PL_FREE_RUN_MODE (1<<1)
#define PAGE1 0x0001
#define BCH_N 15
#define BCH_K 11
#define BCH_R (BCH_N-BCH_K)
#define Preamble 0x38900000;

struct PVTSending
{
	uint32_t WN;
	uint32_t SoW;
	uint32_t ecefX;
	uint32_t ecefY;
	uint32_t ecefZ;
	uint32_t ecefVX;
	uint32_t ecefVY;
	uint32_t ecefVZ;
};

uint32_t Bch_encoder(uint32_t *inbuf, uint32_t* outbuf, uint32_t length);
uint32_t Bch_decoder(uint32_t *inbuf, uint32_t* outbuf, uint32_t length);
void NavSol_Send(struct PVTSending *p, bool freerun_mode);
void GetPVTSending(struct NAVSOL_Typedef MessageIn[], struct PVTSending *MessageSend, uint8_t PredictingTime);
void freeRunMode();
bool set_tx_amplititude(uint16_t v);
bool is_one_pps_available(void);
bool is_tx_sending(void);
uint16_t busy_page(void);
uint32_t get_onepps_interval(void);
uint32_t set_cycles(uint32_t interval);
bool set_page(uint16_t page, bool freerun_mode);
bool set_page_data(uint32_t *buf, uint32_t length, uint16_t page_index);
bool pseudolite_ctrl(bool tx_ena,bool ublox_ena, bool arm_uart2_rx_ublox_data);
bool pseudolite_init(uint16_t sv);
bool reset_gps(void);
bool set_sv_number(uint16_t sv);
bool set_tx_amplititude(uint16_t v);
void esp8266_init();//wang jiabo 
#endif
