#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#ifndef _UBLOX_H_H_
#define _UBLOX_H_H_
/*wang: NAVSOL_Typedef struct*/
struct NAVSOL_Typedef
{
	uint32_t iTOW;
	int32_t fTOW;
	int16_t week;
	uint8_t gpsFix;
	uint8_t flags;
	int32_t ecefX;
	int32_t ecefY;
	int32_t ecefZ;
	uint32_t pAcc;
	int32_t ecefVX;
	int32_t ecefVY;
	int32_t ecefVZ;
	uint32_t sAcc;
	uint16_t pDOP;
	uint8_t reserved1;
	uint8_t numSV;
	uint32_t reserved2;
};
void ubloxInit(void);
uint8_t checkSolFrame(uint8_t *buffer);
void SolFrame(struct NAVSOL_Typedef *p, uint8_t *buffer);
#endif
