#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stm32f4xx.h>
#include <delay.h>
#include "stm32f4_discovery.h"
#include "ublox.h"
#include "radar_xilinx.h"
/*
��������void ubloxInit(void)
����:wu
����: initialize the ublox, including start function, port configuration, message selection and onePPS configuration */
void ubloxInit(void)
{
	uint8_t i = 0; 
	char warmstart [] = {0XB5, 0X62, 0X06, 0X04, 0X04, 0X00, 0X01, 0X00, 0X02, 0X00, 0X11, 0X6C};
  //char coldstart [] ={0XB5, 0X62, 0X06, 0X04, 0X04, 0X00, 0XFF, 0X87, 0X02, 0X00, 0X96, 0XF9};
	//char NAV_POSECEF [] = {0XB5, 0X62, 0X01, 0X01, 0X00, 0X00, 0X02, 0X07};
	char config_port[28]     ={0XB5, 0X62, 0X06, 0X00, 0X14, 0X00, 0X01, 0X00, 0X00, 0X00, 0XD0, 0X08, 0X00, 0X00, 0X80, 0X25, 0X00, 0X00, 0X07, 0X00, 0X01, 0X00, 0X00, 0X00, 0X00, 0X00, 0XA0, 0XA9};
//	char config_port_check[9] = {0xB5, 0x62, 0x06, 0x00, 0x01, 0x00, 0x01, 0x08, 0x22};
  char config_message[16]={0xB5,0x62,0x06,0x01,0x08,0x00,0x01,0x06,0x00,0x01,0x00,0x00,0x00,0x00,0x17,0xDA};
//	char config_message_check[10] = {0xB5, 0x62, 0x06, 0x01, 0x02, 0x00, 0x01, 0x06, 0x10, 0x39};
	char config_timepulse[28]={0xB5,0x62,0x06,0x07,0x14,0x00,0x40,0x42,0x0F,0x00,0x20,0xA1,0x07,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x40,0x00,0x00,0x00,0x00,0x00,0xBB,0x3A};

		for(i=0;i<12;i++)//������
	{
			USART2->DR = warmstart[i];	
			while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);	
	} 
	delay_ms(200);
	for(i=0;i<28;i++)//�˿�����
	{
			USART2->DR = config_port[i];	
			while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);	
	} 
  delay_ms(200);
	for(i=0;i<16;i++)//ѡ��NAV_SOLUTION
	{
			USART2->DR = config_message[i];	
			while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);	
	} 
	
	delay_ms(200);
	for(i=0;i<28;i++)//����������
	{
			USART2->DR = config_timepulse[i];	
			while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);	
	} 
}
/*
��������uint8_t checkSolFrame(uint8_t *buffer)
������һ��ָ�������ָ��
���ܣ�1.���յ������������飬2.������У�飬ͨ��У�鷵���棬δͨ��У�鷵�ؼ�*/
uint8_t checkSolFrame(uint8_t *buffer)
{
				
				uint8_t j = 0;
				uint16_t utemp = 0;
				uint8_t CK_A = 0;
				uint8_t CK_B = 0;
				for(j=0;j<28;j++)
				{
					utemp = FPGA_read((j+1));
					buffer[(2*j)] = (utemp>>8)&0x00ff;
					buffer[(2*j+1)] = (utemp&0x00ff);
					CK_A = CK_A + buffer[(2*j)];
					CK_B = CK_B + CK_A;
					CK_A = CK_A + buffer[(2*j+1)];
					CK_B = CK_B + CK_A;
				}
				utemp = FPGA_read(29);
				buffer[56] = (utemp>>8)&0x00ff;
				buffer[57] = utemp&0x00ff;
				if((CK_A == buffer[56]) && (CK_B == buffer[57]))
				{
					return 1;
				}
				else
					return 0;
}
/*
������:void SolFrame(struct NAVSOL_Typedef *p, uint8_t *buffer)
������ָ��ṹ���ָ�룬ָ�������ָ��
���ܣ������ݽ���������ṹ��*/
void SolFrame(struct NAVSOL_Typedef *p, uint8_t *buffer)
{
	uint8_t utemp8 = 0;
	uint16_t utemp16 = 0;
	int16_t itemp16 = 0;
	uint32_t utemp = 0;
	int32_t itemp = 0;
	utemp = buffer[7];
	utemp = (utemp<<8)+buffer[6];
	utemp = (utemp<<8)+buffer[5];
	utemp = (utemp<<8)+buffer[4];
	p->iTOW = utemp;

	utemp = buffer[11];
	utemp = (utemp<<8)+buffer[10];
	utemp = (utemp<<8)+buffer[9];
	utemp = (utemp<<8)+buffer[8];
	itemp = utemp;
	p->fTOW = utemp;

	utemp16 = buffer[13];
	utemp16 = (utemp16<<8)+buffer[12];
	itemp16 = utemp16;
	p->week = itemp16;

	utemp8 = buffer[14];
	p->gpsFix = utemp8;

	utemp8 = buffer[15];
	p->flags = utemp8;
	
	utemp = buffer[19];
	utemp = (utemp<<8)+buffer[18];
	utemp = (utemp<<8)+buffer[17];
	utemp = (utemp<<8)+buffer[16];
	itemp = utemp;
	p->ecefX = itemp;
	
	utemp = buffer[23];
	utemp = (utemp<<8)+buffer[22];
	utemp = (utemp<<8)+buffer[21];
	utemp = (utemp<<8)+buffer[20];
	itemp = utemp;
	p->ecefY = itemp;
	
	utemp = buffer[27];
	utemp = (utemp<<8)+buffer[26];
	utemp = (utemp<<8)+buffer[25];
	utemp = (utemp<<8)+buffer[24];
	itemp = utemp;
	p->ecefZ = itemp;
	
	utemp = buffer[31];
	utemp = (utemp<<8)+buffer[30];
	utemp = (utemp<<8)+buffer[29];
	utemp = (utemp<<8)+buffer[28];
	p->pAcc = utemp;
	
	utemp = buffer[35];
	utemp = (utemp<<8)+buffer[34];
	utemp = (utemp<<8)+buffer[33];
	utemp = (utemp<<8)+buffer[32];
	itemp = utemp;
	p->ecefVX = itemp;
	
	utemp = buffer[39];
	utemp = (utemp<<8)+buffer[38];
	utemp = (utemp<<8)+buffer[37];
	utemp = (utemp<<8)+buffer[36];
	itemp = utemp;
	p->ecefVY = itemp;
	
	utemp = buffer[43];
	utemp = (utemp<<8)+buffer[42];
	utemp = (utemp<<8)+buffer[41];
	utemp = (utemp<<8)+buffer[40];
	itemp = utemp;
	p->ecefVZ = itemp;
	
	utemp = buffer[47];
	utemp = (utemp<<8)+buffer[46];
	utemp = (utemp<<8)+buffer[45];
	utemp = (utemp<<8)+buffer[44];
	p->sAcc = utemp;
	
	utemp16 = buffer[48];
	utemp = (utemp<<8)+buffer[49];
	p->pDOP = utemp;
	
	utemp8 = buffer[50];
	p->reserved1 = utemp8;

	utemp8 = buffer[51];
	p->numSV = utemp8;
	
	utemp = buffer[55];
	utemp = (utemp<<8)+buffer[54];
	utemp = (utemp<<8)+buffer[53];
	utemp = (utemp<<8)+buffer[52];
	p->reserved2 = utemp;
	
}
