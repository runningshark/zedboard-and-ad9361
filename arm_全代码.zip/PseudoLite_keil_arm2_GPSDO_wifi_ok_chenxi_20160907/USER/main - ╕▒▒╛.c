/*****************************************************************************
 *   @file   main.c
 *   @brief  Implementation of Main Function.
 *   @author chenxi (chenxiee@tsinghua.edu.cn)
******************************************************************************
 * Copyright 2015(c) Space Center, Tsinghua University, China.
 *
 * All rights reserved. 
 *****************************************************************************/
 
#include "stm32f4_discovery.h"
#include <stdio.h>
#include "stm32f4xx_usart.h"
#include "config.h"
#include "led.h"
#include "delay.h"
#include "radar_xilinx.h"
#include "platform.h"
#include "ublox.h"
#include "pseudolite.h"
#include "ad9361_api.h"
#include "ad9361.h"
#include "24cxx.h"
#include "timer.h"
#include "sys.h"
#define PL_TX_FREQ 32768000
//#define XILINX //wang
#define SPI2ASAD9361_CONFIG
#define BYTE_TRUE 0X55
#define BYTE_FALSE 0XAA
uint8_t OneppsFlag = BYTE_FALSE;

//gong
uint8_t SBUF[8]={0X00,0X11,0X22,0X33,0X44,0X55,0X66,0X77};// uart4 buffer
uint8_t bufcount = 0;
bool frameheadfound = false;
bool is_ublox_0xb5found=false;
bool is_ublox_0x62found=false;
bool is_ublox_0x01found=false;
bool is_ublox_ID_NavLLHFound=false;
bool is_ublox_ID_NavTimegpsFound=false;
bool is_ublox_ID_NavsvinfoFound=false;
bool is_ublox_data_NavLLH_catched=false;
bool is_ublox_data_NavTimegps_catched=false;
bool is_ublox_data_Navsvinfo_catched=false;
uint8_t Usart2SBUF[256];
uint8_t Usart2SBUFCount=0;
uint16_t DataLength=0;

int xk = 0;

double yk = 0;
int xk_1 = 0;
double yk_1 = 0;
#define b0 57.83
#define b1 31.16
#define  K  57.0
#define DACREGVALUE  39890
int CurrentRefValue=DACREGVALUE;
void SPI_GPIOConfig(void)
{
#ifdef SPI2ASAD9361_CONFIG
	 GPIO_InitTypeDef GPIO_InitStructure;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);  //����ʱ��
    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;  //���ų�ʼ��
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB,&GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOB,GPIO_PinSource13,GPIO_AF_SPI2);  //�����ŵĸ��ù���
    GPIO_PinAFConfig(GPIOB,GPIO_PinSource14,GPIO_AF_SPI2);
    GPIO_PinAFConfig(GPIOB,GPIO_PinSource15,GPIO_AF_SPI2);
	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;  //���ų�ʼ��
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_12 ;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB,&GPIO_InitStructure);
	
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);  //����ʱ��
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;  //���ų�ʼ��
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7|GPIO_Pin_6|GPIO_Pin_5 ;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA,&GPIO_InitStructure);
		#ifdef XILINX  //wang
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
    GPIO_Init(GPIOA,&GPIO_InitStructure);
		#else	
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);  //����ʱ��
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;  //���ų�ʼ��
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_13;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC,&GPIO_InitStructure);
		#endif
#else
	//SPI1  used for  spi1	
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);  //����ʱ��
    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;  //���ų�ʼ��
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA,&GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA,GPIO_PinSource5,GPIO_AF_SPI1);  //�����ŵĸ��ù���
    GPIO_PinAFConfig(GPIOA,GPIO_PinSource6,GPIO_AF_SPI1);
    GPIO_PinAFConfig(GPIOA,GPIO_PinSource7,GPIO_AF_SPI1);
		
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;  //���ų�ʼ��
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA,&GPIO_InitStructure);
	
		#ifdef XILINX  //wang
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
    GPIO_Init(GPIOA,&GPIO_InitStructure);
		#else	 
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);  //����ʱ��
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;  //���ų�ʼ��
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC,&GPIO_InitStructure);
		select_spi_port(SPI_NONE);
		#endif
#endif
			


}
SPI_InitTypeDef SPI_InitStructure; 
void SPI_Config(void)
{
    SPI_GPIOConfig();
// RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2,ENABLE);  //ʱ��
    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;  //ȫ˫��ģʽ
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;   //��Ϊ����ʹ��
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;   //���ݳ���8
    SPI_InitStructure.SPI_CPOL  = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;   //��������NSS����
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_8;
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;
//used for SPI2----axisY
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2,ENABLE);  //ʱ��
		SPI_Init(SPI2,&SPI_InitStructure);
    SPI_Cmd(SPI2,ENABLE);
}


/*************************************************
Function: void USART_Config(void)      
Description: USART���ú���             
Input: ��                              
Output:��                              
Return:��                              
*************************************************/  

void USART_Config(void)
{

GPIO_InitTypeDef GPIO_InitStructure;
USART_InitTypeDef USART_InitStructure;
USART_ClockInitTypeDef USART_ClockInitStruct;
RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE); //����USART2ʱ��
RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE); //����UART4ʱ

RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);  //����GPIOAʱ��
GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);//���൱��M3�Ŀ�������ʱ�ӣ�ֻ���ø��õ����ţ�
GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2);//

GPIO_PinAFConfig(GPIOA, GPIO_PinSource0, GPIO_AF_UART4);//���൱��M3�Ŀ�������ʱ�ӣ�ֻ���ø��õ����ţ�
GPIO_PinAFConfig(GPIOA, GPIO_PinSource1, GPIO_AF_UART4);//	
	
/*����GPIOA*/
GPIO_StructInit(&GPIO_InitStructure);      //ȱʡֵ����

/*����GPIOA_Pin2ΪTX���*/
GPIO_InitStructure.GPIO_Pin=GPIO_Pin_2;
GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;     //����Ϊ���ã�����ΪAF��OUT����
GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; //���츴�����
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP; //����
GPIO_Init(GPIOA,&GPIO_InitStructure);

/*����GPIOA_Pin3ΪRX����*/
GPIO_InitStructure.GPIO_Pin=GPIO_Pin_3;
GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;     //��Ҳ����Ϊ���ã���M3��ͬ��
GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; //���츴�����
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP; //����
GPIO_Init(GPIOA,&GPIO_InitStructure);

/*����GPI0A_Pin0*/
GPIO_InitStructure.GPIO_Pin=GPIO_Pin_0;
GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;     //����Ϊ���ã�����ΪAF��OUT����
GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
GPIO_Init(GPIOA,&GPIO_InitStructure);
/*����GPIOA_Pin1ΪRX����*/
GPIO_InitStructure.GPIO_Pin=GPIO_Pin_1;
GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;     //��Ҳ����Ϊ���ã���M3��ͬ��
GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
GPIO_Init(GPIOA,&GPIO_InitStructure);


/*IO���Ÿ��ù������ã���֮ǰ�汾��ͬ*/
/*����USART2*/
USART_StructInit(&USART_InitStructure);
USART_InitStructure.USART_BaudRate =9600;
USART_InitStructure.USART_WordLength = USART_WordLength_8b;
USART_InitStructure.USART_StopBits = USART_StopBits_1;
USART_InitStructure.USART_Parity = USART_Parity_No;
USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

USART_Init(USART2, &USART_InitStructure);
USART_ClockStructInit(&USART_ClockInitStruct);    //֮ǰû������ȱʡֵ���ǲ��е�
USART_ClockInit(USART2, &USART_ClockInitStruct);
USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);    //ʹ�� USART2�ж�
USART_Cmd(USART2, ENABLE);         //ʹ�� USART6 
//USART_ClearFlag(USART2, USART_FLAG_TC);

USART_InitStructure.USART_BaudRate =115200;
USART_Init(UART4, &USART_InitStructure);
USART_ITConfig(UART4,USART_IT_RXNE, ENABLE);  //ʹ�� USART4�ж�
USART_Cmd(UART4, ENABLE);       //ʹ�� USART4  


}

/*************************************************
Function: void Delay(uint32_t nCount)  
Description: ��ʱ����                  
Input: ��ʱ��ʱ��                      
Output:��                              
Return:��                              
*************************************************/
 


//extern testSPI(void);
//extern signed int calibration_ADC(unsigned int CAL_CMD,unsigned int ADC_data_wait);
//extern read_ADC_ALLREG(void);
//extern ADC_configuration(void);
//int if_cal;

unsigned char tmp=0x00;
unsigned char tmp1=0x01;

uint16_t  rr=0x00;


uint8_t spi_rw(SPI_TypeDef *spin,uint8_t datatosend)
{
	while(SPI_I2S_GetFlagStatus(spin,SPI_I2S_FLAG_TXE)==RESET);
	spin->DR = datatosend;
	while(SPI_I2S_GetFlagStatus(spin,SPI_I2S_FLAG_RXNE)==RESET);
	return spin->DR;
}
unsigned char command1;
unsigned char command2;


/* Private macro -------------------------------------------------------------*/                                                                
/* Private variables ---------------------------------------------------------*/                                                                
//GPIO_InitTypeDef GPIO_InitStructure;      
//SPI_InitTypeDef SPI1_InitSturcture;
//USART_InitTypeDef USART_InitSturcture;
//NVIC_InitTypeDef NVIC_InitStructure;

/* Private function prototypes -----------------------------------------------*/ 
	int fputc(int ch, FILE *f)	//??????
	{
		USART_SendData(USART2, (u8) ch);
		while (!(USART2->SR & USART_FLAG_TXE));
		return (ch);
	}
	
	int GetKey (void)	//??????
	{
		while (!(USART2->SR & USART_FLAG_RXNE));
		return ((int)(USART2->DR & 0x1FF));
	}


uint8_t ret=0X00;
/*
	Author: wang
	Function:  EXTI
*/
	/*name of the function: void EXTI_GPIO_Congig(void)
	function : initialize the GPIOs used for external interruption
	*/	
void EXTI_GPIO_Congig(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG,ENABLE); 
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_Pin = GPIO_PinSource8;//GPIO PA8 is used for the external interruption 
  GPIO_InitStructure.GPIO_Speed =GPIO_Speed_50MHz;
//  GPIO_Init(GPIOA,&GPIO_InitStructure);
	
//	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG,ENABLE); 
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//  GPIO_InitStructure.GPIO_Pin = GPIO_PinSource0;//GPIO PB0 is used for the external interruption 
//  GPIO_InitStructure.GPIO_Speed =GPIO_Speed_50MHz;
//  GPIO_Init(GPIOB,&GPIO_InitStructure);
//	
  
}
	/*name of the function: EXTI_Config(void)
	function : initialize external interruption mode
	*/	
void EXTI_Config(void)
{
	EXTI_InitTypeDef EXTI_InitStructure;
  EXTI_GPIO_Congig();

  // RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG,ENABLE);
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource8);
  EXTI_InitStructure.EXTI_Line = EXTI_Line8;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
  EXTI_Init(&EXTI_InitStructure);
	
//	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource0);
//  EXTI_InitStructure.EXTI_Line = EXTI_Line0;
//  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
//  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
//  EXTI_Init(&EXTI_InitStructure);
}
	/*name of the function: void NVIC_Config(void)
	function : config the priority of external interruption 
	*/
void NVIC_Config(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;
//  /* Enable the USARTx Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;//LINE8------->EXTI9_5
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
//	NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;//LINE0------->EXTI0
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
//  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//	NVIC_Init(&NVIC_InitStructure);
	
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
	NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;	
	NVIC_Init(&NVIC_InitStructure);
	
//	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);//����USART2�����ж�
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;	
	NVIC_Init(&NVIC_InitStructure);
	
	
	
}	


 
AD9361_InitParam default_init_param = {
	/* Identification number */
	0,		//id_no;
	/* Reference Clock */
	//40000000UL,	//reference_clk_rate
	  40000000UL,	//reference_clk_rate  wangfei
	/* Base Configuration */
	0,		//two_rx_two_tx_mode_enable *** adi,2rx-2tx-mode-enable
	1,		//frequency_division_duplex_mode_enable *** adi,frequency-division-duplex-mode-enable
	
	0,		//frequency_division_duplex_independent_mode_enable *** adi,frequency-division-duplex-independent-mode-enable
	
	//1,		//frequency_division_duplex_independent_mode_enable *** adi,frequency-division-duplex-independent-mode-enable
	0,		//tdd_use_dual_synth_mode_enable *** adi,tdd-use-dual-synth-mode-enable
	
	0,		//tdd_skip_vco_cal_enable *** adi,tdd-skip-vco-cal-enable
	0,		//tx_fastlock_delay_ns *** adi,tx-fastlock-delay-ns
	0,		//rx_fastlock_delay_ns *** adi,rx-fastlock-delay-ns
	0,		//rx_fastlock_pincontrol_enable *** adi,rx-fastlock-pincontrol-enable
	0,		//tx_fastlock_pincontrol_enable *** adi,tx-fastlock-pincontrol-enable
	0,		//external_rx_lo_enable *** adi,external-rx-lo-enable
	0,		//external_tx_lo_enable *** adi,external-tx-lo-enable
	5,		//dc_offset_tracking_update_event_mask *** adi,dc-offset-tracking-update-event-mask
	6,		//dc_offset_attenuation_high_range *** adi,dc-offset-tracking-update-event-mask
	5,		//dc_offset_attenuation_low_range *** adi,dc-offset-tracking-update-event-mask
	0x28,	//dc_offset_count_high_range *** adi,dc-offset-tracking-update-event-mask
	0x32,	//dc_offset_count_low_range *** adi,dc-offset-tracking-update-event-mask
	0,		//tdd_use_fdd_vco_tables_enable *** adi,tdd-use-fdd-vco-tables-enable
	0,		//split_gain_table_mode_enable *** adi,split-gain-table-mode-enable
	MAX_SYNTH_FREF,	//trx_synthesizer_target_fref_overwrite_hz *** adi,trx-synthesizer-target-fref-overwrite-hz
	0,		// qec_tracking_slow_mode_enable *** adi,qec-tracking-slow-mode-enable
	/* ENSM Control */
	0,		//ensm_enable_pin_pulse_mode_enable *** adi,ensm-enable-pin-pulse-mode-enable
	0,		//ensm_enable_txnrx_control_enable *** adi,ensm-enable-txnrx-control-enable    0 spi control
	/* LO Control */
	2000000000UL,	//rx_synthesizer_frequency_hz *** adi,rx-synthesizer-frequency-hz
	921000000UL,	//tx_synthesizer_frequency_hz *** adi,tx-synthesizer-frequency-hz
	/* Rate & BW Control */
	
	{983040000, 245760000, 122880000, 61440000, 30720000, 30720000},//uint32_t	rx_path_clock_frequencies[6] *** adi,rx-path-clock-frequencies
	{983040000, 122880000, 122880000, 61440000, 30720000, 30720000},//uint32_t	tx_path_clock_frequencies[6] *** adi,tx-path-clock-frequencies
  //{1047552000, 523776000, 261888000, 130944000, 65472000, 32736000},	
  //{1047552000, 261888000, 261888000, 130944000, 65472000, 32736000},
	
	//3000000,//rf_rx_bandwidth_hz *** adi,rf-rx-bandwidth-hz
	//3000000,//rf_tx_bandwidth_hz *** adi,rf-tx-bandwidth-hz
	27515168,
	4514189,
	/* RF Port Control */
	0,		//rx_rf_port_input_select *** adi,rx-rf-port-input-select   rxa �������ʹ��
	0,		//tx_rf_port_input_select *** adi,tx-rf-port-input-select   txa ������ʹ��
	/* TX Attenuation Control */
	0,	//tx_attenuation_mdB *** adi,tx-attenuation-mdB
	0,		//update_tx_gain_in_alert_enable *** adi,update-tx-gain-in-alert-enable
	/* Reference Clock Control */
	0,		//xo_disable_use_ext_refclk_enable *** adi,xo-disable-use-ext-refclk-enable  ����ʹ�õ��Ǿ���
	{8, 5920},	//dcxo_coarse_and_fine_tune[2] *** adi,dcxo-coarse-and-fine-tune
	//0,		//clk_output_mode_select *** adi,clk-output-mode-select            �����ǽ�ֹ�������������һ������������
	8,		//clk_output_mode_select *** adi,clk-output-mode-select            ���ADC_CLK/64����������
	/* Gain Control */
	2,		//gc_rx1_mode *** adi,gc-rx1-mode
	2,		//gc_rx2_mode *** adi,gc-rx2-mode
	58,		//gc_adc_large_overload_thresh *** adi,gc-adc-large-overload-thresh
	4,		//gc_adc_ovr_sample_size *** adi,gc-adc-ovr-sample-size
	47,		//gc_adc_small_overload_thresh *** adi,gc-adc-small-overload-thresh
	8192,	//gc_dec_pow_measurement_duration *** adi,gc-dec-pow-measurement-duration
	0,		//gc_dig_gain_enable *** adi,gc-dig-gain-enable
	800,	//gc_lmt_overload_high_thresh *** adi,gc-lmt-overload-high-thresh
	704,	//gc_lmt_overload_low_thresh *** adi,gc-lmt-overload-low-thresh
	24,		//gc_low_power_thresh *** adi,gc-low-power-thresh
	15,		//gc_max_dig_gain *** adi,gc-max-dig-gain
	/* Gain MGC Control */
	2,		//mgc_dec_gain_step *** adi,mgc-dec-gain-step
	2,		//mgc_inc_gain_step *** adi,mgc-inc-gain-step
	0,		//mgc_rx1_ctrl_inp_enable *** adi,mgc-rx1-ctrl-inp-enable
	0,		//mgc_rx2_ctrl_inp_enable *** adi,mgc-rx2-ctrl-inp-enable
	0,		//mgc_split_table_ctrl_inp_gain_mode *** adi,mgc-split-table-ctrl-inp-gain-mode
	/* Gain AGC Control */
	10,		//agc_adc_large_overload_exceed_counter *** adi,agc-adc-large-overload-exceed-counter
	2,		//agc_adc_large_overload_inc_steps *** adi,agc-adc-large-overload-inc-steps
	0,		//agc_adc_lmt_small_overload_prevent_gain_inc_enable *** adi,agc-adc-lmt-small-overload-prevent-gain-inc-enable
	10,		//agc_adc_small_overload_exceed_counter *** adi,agc-adc-small-overload-exceed-counter
	4,		//agc_dig_gain_step_size *** adi,agc-dig-gain-step-size
	3,		//agc_dig_saturation_exceed_counter *** adi,agc-dig-saturation-exceed-counter
	1000,	// agc_gain_update_interval_us *** adi,agc-gain-update-interval-us
	0,		//agc_immed_gain_change_if_large_adc_overload_enable *** adi,agc-immed-gain-change-if-large-adc-overload-enable
	0,		//agc_immed_gain_change_if_large_lmt_overload_enable *** adi,agc-immed-gain-change-if-large-lmt-overload-enable
	10,		//agc_inner_thresh_high *** adi,agc-inner-thresh-high
	1,		//agc_inner_thresh_high_dec_steps *** adi,agc-inner-thresh-high-dec-steps
	12,		//agc_inner_thresh_low *** adi,agc-inner-thresh-low
	1,		//agc_inner_thresh_low_inc_steps *** adi,agc-inner-thresh-low-inc-steps
	10,		//agc_lmt_overload_large_exceed_counter *** adi,agc-lmt-overload-large-exceed-counter
	2,		//agc_lmt_overload_large_inc_steps *** adi,agc-lmt-overload-large-inc-steps
	10,		//agc_lmt_overload_small_exceed_counter *** adi,agc-lmt-overload-small-exceed-counter
	5,		//agc_outer_thresh_high *** adi,agc-outer-thresh-high
	2,		//agc_outer_thresh_high_dec_steps *** adi,agc-outer-thresh-high-dec-steps
	18,		//agc_outer_thresh_low *** adi,agc-outer-thresh-low
	2,		//agc_outer_thresh_low_inc_steps *** adi,agc-outer-thresh-low-inc-steps
	1,		//agc_attack_delay_extra_margin_us; *** adi,agc-attack-delay-extra-margin-us
	0,		//agc_sync_for_gain_counter_enable *** adi,agc-sync-for-gain-counter-enable
	/* Fast AGC */
	64,		//fagc_dec_pow_measuremnt_duration ***  adi,fagc-dec-pow-measurement-duration
	260,	//fagc_state_wait_time_ns ***  adi,fagc-state-wait-time-ns
		/* Fast AGC - Low Power */
	0,		//fagc_allow_agc_gain_increase ***  adi,fagc-allow-agc-gain-increase-enable
	5,		//fagc_lp_thresh_increment_time ***  adi,fagc-lp-thresh-increment-time
	1,		//fagc_lp_thresh_increment_steps ***  adi,fagc-lp-thresh-increment-steps
		/* Fast AGC - Lock Level */
	10,		//fagc_lock_level ***  adi,fagc-lock-level */
	1,		//fagc_lock_level_lmt_gain_increase_en ***  adi,fagc-lock-level-lmt-gain-increase-enable
	5,		//fagc_lock_level_gain_increase_upper_limit ***  adi,fagc-lock-level-gain-increase-upper-limit
		/* Fast AGC - Peak Detectors and Final Settling */
	1,		//fagc_lpf_final_settling_steps ***  adi,fagc-lpf-final-settling-steps
	1,		//fagc_lmt_final_settling_steps ***  adi,fagc-lmt-final-settling-steps
	3,		//fagc_final_overrange_count ***  adi,fagc-final-overrange-count
		/* Fast AGC - Final Power Test */
	0,		//fagc_gain_increase_after_gain_lock_en ***  adi,fagc-gain-increase-after-gain-lock-enable
		/* Fast AGC - Unlocking the Gain */
		/* 0 = MAX Gain, 1 = Optimized Gain, 2 = Set Gain */
	0,		//fagc_gain_index_type_after_exit_rx_mode ***  adi,fagc-gain-index-type-after-exit-rx-mode
	1,		//fagc_use_last_lock_level_for_set_gain_en ***  adi,fagc-use-last-lock-level-for-set-gain-enable
	1,		//fagc_rst_gla_stronger_sig_thresh_exceeded_en ***  adi,fagc-rst-gla-stronger-sig-thresh-exceeded-enable
	5,		//fagc_optimized_gain_offset ***  adi,fagc-optimized-gain-offset
	10,		//fagc_rst_gla_stronger_sig_thresh_above_ll ***  adi,fagc-rst-gla-stronger-sig-thresh-above-ll
	1,		//fagc_rst_gla_engergy_lost_sig_thresh_exceeded_en ***  adi,fagc-rst-gla-engergy-lost-sig-thresh-exceeded-enable
	1,		//fagc_rst_gla_engergy_lost_goto_optim_gain_en ***  adi,fagc-rst-gla-engergy-lost-goto-optim-gain-enable
	10,		//fagc_rst_gla_engergy_lost_sig_thresh_below_ll ***  adi,fagc-rst-gla-engergy-lost-sig-thresh-below-ll
	8,		//fagc_energy_lost_stronger_sig_gain_lock_exit_cnt ***  adi,fagc-energy-lost-stronger-sig-gain-lock-exit-cnt
	1,		//fagc_rst_gla_large_adc_overload_en ***  adi,fagc-rst-gla-large-adc-overload-enable
	1,		//fagc_rst_gla_large_lmt_overload_en ***  adi,fagc-rst-gla-large-lmt-overload-enable
	0,		//fagc_rst_gla_en_agc_pulled_high_en ***  adi,fagc-rst-gla-en-agc-pulled-high-enable
	0,		//fagc_rst_gla_if_en_agc_pulled_high_mode ***  adi,fagc-rst-gla-if-en-agc-pulled-high-mode
	64,		//fagc_power_measurement_duration_in_state5 ***  adi,fagc-power-measurement-duration-in-state5
	/* RSSI Control */
	1,		//rssi_delay *** adi,rssi-delay
	1000,	//rssi_duration *** adi,rssi-duration
	3,		//rssi_restart_mode *** adi,rssi-restart-mode
	0,		//rssi_unit_is_rx_samples_enable *** adi,rssi-unit-is-rx-samples-enable
	1,		//rssi_wait *** adi,rssi-wait
	/* Aux ADC Control */
	256,	//aux_adc_decimation *** adi,aux-adc-decimation
	40000000UL,	//aux_adc_rate *** adi,aux-adc-rate    //����Ƿ���Ҫ�ĳ�48MHz��
	/* AuxDAC Control */
	1,		//aux_dac_manual_mode_enable ***  adi,aux-dac-manual-mode-enable
	0,		//aux_dac1_default_value_mV ***  adi,aux-dac1-default-value-mV
	0,		//aux_dac1_active_in_rx_enable ***  adi,aux-dac1-active-in-rx-enable
	0,		//aux_dac1_active_in_tx_enable ***  adi,aux-dac1-active-in-tx-enable
	0,		//aux_dac1_active_in_alert_enable ***  adi,aux-dac1-active-in-alert-enable
	0,		//aux_dac1_rx_delay_us ***  adi,aux-dac1-rx-delay-us
	0,		//aux_dac1_tx_delay_us ***  adi,aux-dac1-tx-delay-us
	0,		//aux_dac2_default_value_mV ***  adi,aux-dac2-default-value-mV
	0,		//aux_dac2_active_in_rx_enable ***  adi,aux-dac2-active-in-rx-enable
	0,		//aux_dac2_active_in_tx_enable ***  adi,aux-dac2-active-in-tx-enable
	0,		//aux_dac2_active_in_alert_enable ***  adi,aux-dac2-active-in-alert-enable
	0,		//aux_dac2_rx_delay_us ***  adi,aux-dac2-rx-delay-us
	0,		//aux_dac2_tx_delay_us ***  adi,aux-dac2-tx-delay-us
	/* Temperature Sensor Control */
	256,	//temp_sense_decimation *** adi,temp-sense-decimation
	1000,	//temp_sense_measurement_interval_ms *** adi,temp-sense-measurement-interval-ms
	0xCE,	//temp_sense_offset_signed *** adi,temp-sense-offset-signed
	1,		//temp_sense_periodic_measurement_enable *** adi,temp-sense-periodic-measurement-enable
	/* Control Out Setup */
	0xFF,	//ctrl_outs_enable_mask *** adi,ctrl-outs-enable-mask
	//0x00,	//ctrl_outs_enable_mask *** adi,ctrl-outs-enable-mask
	//0,		//ctrl_outs_index *** adi,ctrl-outs-index
	1,		//CALIBRATION AND ENSM STATES
	/* External LNA Control */
	0,		//elna_settling_delay_ns *** adi,elna-settling-delay-ns
	0,		//elna_gain_mdB *** adi,elna-gain-mdB
	0,		//elna_bypass_loss_mdB *** adi,elna-bypass-loss-mdB
	0,		//elna_rx1_gpo0_control_enable *** adi,elna-rx1-gpo0-control-enable
	0,		//elna_rx2_gpo1_control_enable *** adi,elna-rx2-gpo1-control-enable
	
	/* Digital Interface Control */
	0,		//digital_interface_tune_skip_mode *** adi,digital-interface-tune-skip-mode
	1,		//pp_tx_swap_enable *** adi,pp-tx-swap-enable
	1,		//pp_rx_swap_enable *** adi,pp-rx-swap-enable
	0,		//tx_channel_swap_enable *** adi,tx-channel-swap-enable
	0,		//rx_channel_swap_enable *** adi,rx-channel-swap-enable
	1,		//rx_frame_pulse_mode_enable *** adi,rx-frame-pulse-mode-enable
	//0,		//rx_frame_pulse_mode_enable *** adi,rx-frame-pulse-mode-enable
	
	0,		//two_t_two_r_timing_enable *** adi,2t2r-timing-enable 
	0,		//invert_data_bus_enable *** adi,invert-data-bus-enable
	0,		//invert_data_clk_enable *** adi,invert-data-clk-enable
	0,		//fdd_alt_word_order_enable *** adi,fdd-alt-word-order-enable
	0,		//invert_rx_frame_enable *** adi,invert-rx-frame-enable
	0,		//fdd_rx_rate_2tx_enable *** adi,fdd-rx-rate-2tx-enable
	0,		//swap_ports_enable *** adi,swap-ports-enable
	0,		//single_data_rate_enable *** adi,single-data-rate-enable
	
	0,		//lvds_mode_enable *** adi,lvds-mode-enable
	
	0,		//half_duplex_mode_enable *** adi,half-duplex-mode-enable
	0,		//single_port_mode_enable *** adi,single-port-mode-enable
	//0,		//full_port_enable *** adi,full-port-enable
	1,		//full_port_enable *** adi,full-port-enable
	
	0,		//full_duplex_swap_bits_enable *** adi,full-duplex-swap-bits-enable
	0,		//delay_rx_data *** adi,delay-rx-data
	0,		//rx_data_clock_delay *** adi,rx-data-clock-delay
	4,		//rx_data_delay *** adi,rx-data-delay
	7,		//tx_fb_clock_delay *** adi,tx-fb-clock-delay
	0,		//tx_data_delay *** adi,tx-data-delay
	150,	//lvds_bias_mV *** adi,lvds-bias-mV
	//1,	//lvds_rx_onchip_termination_enable *** adi,lvds-rx-onchip-termination-enable
	0,		//lvds_rx_onchip_termination_enable ����ģʽ����ʹ����� wangfei
	0,		//rx1rx2_phase_inversion_en *** adi,rx1-rx2-phase-inversion-enable
	0xFF,	//lvds_invert1_control *** adi,lvds-invert1-control
	0x0F,	//lvds_invert2_control *** adi,lvds-invert2-control
	/* Tx Monitor Control */
	37000,	//low_high_gain_threshold_mdB *** adi,txmon-low-high-thresh
	0,		//low_gain_dB *** adi,txmon-low-gain
	24,		//high_gain_dB *** adi,txmon-high-gain
	0,		//tx_mon_track_en *** adi,txmon-dc-tracking-enable
	0,		//one_shot_mode_en *** adi,txmon-one-shot-mode-enable
	511,	//tx_mon_delay *** adi,txmon-delay
	8192,	//tx_mon_duration *** adi,txmon-duration
	2,		//tx1_mon_front_end_gain *** adi,txmon-1-front-end-gain
	2,		//tx2_mon_front_end_gain *** adi,txmon-2-front-end-gain
	48,		//tx1_mon_lo_cm *** adi,txmon-1-lo-cm
	48,		//tx2_mon_lo_cm *** adi,txmon-2-lo-cm
	/* GPIO definitions */
	0,		//gpio_resetb;	/* reset-gpios */
	/* MCS Sync */
	1,		//gpio_sync;		/* sync-gpios */
	2,		//gpio_cal_sw1;	/* cal-sw1-gpios */
	3		//gpio_cal_sw2;	/* cal-sw2-gpios */
};


AD9361_RXFIRConfig rx_fir_config = {
	3, // rx;
	0, // rx_gain;
	1, // rx_dec;
	{0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 -4, -6, -37, 35, 186, 86, -284, 315,
	 107, 219, -4, 271, 558, -307, -1182, -356,
	 658, 157, 207, 1648, 790, -2525, -2553, 748,
	 865, -476, 3737, 6560, -3583, -14731, -5278, 14819,
	 14819, -5278, -14731, -3583, 6560, 3737, -476, 865,
	 748, -2553, -2525, 790, 1648, 207, 157, 658,
	 -356, -1182, -307, 558, 271, -4, 219, 107,
	 -315, -284, 86, 186, 35, -37, -6, -4,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0}, // rx_coef[128];
	 128 // rx_coef_size
};
/*
AD9361_TXFIRConfig tx_fir_config = {
	3, // tx;
	-6, // tx_gain;
	1, // tx_inc;
	{0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 -4, -6, -37, 35, 186, 86, -284, 315,
	 107, 219, -4, 271, 558, -307, -1182, -356,
	 658, 157, 207, 1648, 790, -2525, -2553, 748,
	 865, -476, 3737, 6560, -3583, -14731, -5278, 14819,
	 14819, -5278, -14731, -3583, 6560, 3737, -476, 865,
	 748, -2553, -2525, 790, 1648, 207, 157, 658,
	 -356, -1182, -307, 558, 271, -4, 219, 107,
	 -315, -284, 86, 186, 35, -37, -6, -4,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0}, // tx_coef[128];
	 128 // tx_coef_size
};
*/
AD9361_TXFIRConfig tx_fir_config = {
	3, // tx;
	-6, // tx_gain;
	2, // tx_inc;
	{	
2946,
-8842,
12924,
-13081,
10814,
-9057,
6764,
-6078,
4056,
-4360,
2310,
-3412,
1163,
-2866,
424,
-2482,
9,
-2100,
-114,
-1629,
32,
-1034,
406,
-338,
925,
391,
1478,
1035,
1920,
1464,
2110,
1560,
1928,
1240,
1328,
496,
335,
-591,
-915,
-1844,
-2208,
-3013,
-3252,
-3801,
-3760,
-3909,
-3465,
-3125,
-2197,
-1329,
66,
1435,
3206,
4942,
6948,
8844,
10871,
12700,
14503,
16021,
17381,
18376,
19113,
19456,
19456,
19113,
18376,
17381,
16021,
14503,
12700,
10871,
8844,
6948,
4942,
3206,
1435,
66,
-1329,
-2197	
	
	}, // tx_coef[128];
	 80 // tx_coef_size
};
struct ad9361_rf_phy *ad9361_phy;		
uint8_t a[2]; //?chenxi

/*CK_A CK_B checksum*/

/*****************************************************************
* chenxi main function
*****************************************************************/
//PB0 is the interrupt to STC89C51
bool isFreeRunMode = false;
uint32_t ad9361register = 0;

bool is_wr_ad9361_freq_to_e2prom=false;
u32 freq_WrToE2prom=0;
bool is_wr_ad9361_amplititude_to_e2prom=false;
u32 amplititude_WrToE2prom=0;
bool is_wr_ad9361_sv_number_to_e2prom=false;
u32 sv_number_WrToE2prom=0;
bool isSystemInitEnd=false;


int main()
{	
  short i=0;
	uint8_t temp = 0;
	uint8_t Message_Num = 0, PredictingTime; //Message_Num: The index of NAVSOL_Message[]; PredictingTime: Needed predicting time length in seconds for MessageSend; Wang Menglu; 20151113
	uint8_t checkframeFlag = 0;
//	uint8_t utemp8=0;
	int32_t LastTime, LastWeek, LocalTime, LocalWeek; //All are for time initializing and frameloss check; Menglu Wang; 20151113
	int32_t ret;
	bool InitTimeFlag = false, SaveLastTime = false, FirstRun = true; //Flags for whether the local time is initialized and whether the first obtained GPS time is saved; Menglu Wang; 20151113 
	bool bool_temp;
	uint32_t OneppsInterval, OneppsGap, LocalInterval;
	uint32_t attenuation_db=10;
	uint8_t buffer[58];//wangjiabo :  define a buffer array, which is used to store the NAVSOL messages
	struct NAVSOL_Typedef NAVSOL_Message[6];//wangjiabo :  define a structure which is used for the description of NAVSOL messages.
	struct PVTSending MessageSend; //Structure to store the message need sending; Wang Menglu; 20151113
	int sample_clk_freq=5000000;
	
	//gong
	u8 count_500ms=0;
	u8 ii=0;
	uint8_t esp_cipsend_NavLLH[17]={'A','T','+','C','I','P','S','E','N','D','=','0',',','3','6',0x0D,0X0A};
	uint8_t esp_cipsend_Navsvinfo[17]={'A','T','+','C','I','P','S','E','N','D','=','0',',','2','4',0x0D,0X0A};
	uint8_t esp_cipsend_NavTimegps[18]={'A','T','+','C','I','P','S','E','N','D','=','0',',','2','0','8',0x0D,0X0A};	
	
	
	delay_init(168);
//	USART_Config();	
	SPI_Config();
	
	FSMC_init();	
	EXTI_Config();
	USART_Config();
	

//	//gong
//	esp8266_init();			
//	AT24CXX_Init();
//	while(AT24CXX_Check())
//	{
//		;
//	}
//	TIM3_Int_Init(5000-1,8400-1);	//��ʱ��ʱ��84M����Ƶϵ��8400������84M/8400=10Khz�ļ���Ƶ�ʣ�����5000��Ϊ500ms     

	
   ad9361_hardware_initial();
   

		ret=ad9361_init(&ad9361_phy, &default_init_param);
		if(ret!=0)
		{
			while(1);
		}
		//ad9361_set_tx_fir_config(ad9361_phy, tx_fir_config);
		//ad9361_set_rx_fir_config(ad9361_phy, rx_fir_config);
		FPGA_write(SAMPLE_CLK_FRE_LOW,sample_clk_freq&0xFFFF);
		FPGA_write(SAMPLE_CLK_FRE_HIGH,(sample_clk_freq>>16)&0xFFFF);
		ad9361_set_tx_sampling_freq(ad9361_phy, PL_TX_FREQ);
		ad9361_en_dis_rx(ad9361_phy, 1, RX_DISABLE);
		ad9361_en_dis_rx(ad9361_phy, 2, RX_DISABLE);
    ad9361register = ad9361_spi_read(ad9361_phy->spi,0X12);

	/*
	while(1)
	{
			USART_SendData(UART4, 0x55);	
			while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
			delay_ms(200);		
	} 
	*/
	ubloxInit();	
	pseudolite_init(1);
	FPGA_write(PSEUDOLITE_CTRL_ADDR,0x0);
	
  //Start GPSDO DAC.
  FPGA_write(DAC_REG_CTRL, 0X1);	
	FPGA_write(DAC_REG_DATA, DACREGVALUE);
  isSystemInitEnd=true;
  NVIC_Config();
//gong
	esp8266_init();			
	AT24CXX_Init();
	while(AT24CXX_Check())
	{
		;
	}
	TIM3_Int_Init(5000-1,8400-1);	//��ʱ��ʱ��84M����Ƶϵ��8400������84M/8400=10Khz�ļ���Ƶ�ʣ�����5000��Ϊ500ms     

		while(1)
		{
			if(is_500msINT)
			{
				is_500msINT=false;
				if(count_500ms==5)count_500ms=0;
				count_500ms++;
				if(count_500ms==1)
				{
					u8 buf[]={0xB5,0x62,0x01,0x02,0x00,0x00,0x03,0x0a};
					while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);	
					USART2->DR = buf[0];	
					while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);	
					USART2->DR = buf[1];	
					while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
					USART2->DR = buf[2];	
					while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
					USART2->DR = buf[3];	
					while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
					USART2->DR = buf[4];	
					while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
					USART2->DR = buf[5];	
					while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
					USART2->DR = buf[6];	
					while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
					USART2->DR = buf[7];	
					while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
				}
				else if(count_500ms==2)
				{
					u8 buf[]={0xB5,0x62,0x01,0x20,0x00,0x00,0x21,0x64};
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[0]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[1]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[2]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[3]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[4]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[5]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[6]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[7]);
//					count_500ms=2;
				}
				else if(count_500ms==3)
				{
					u8 buf[]={0xB5,0x62,0x01,0x30,0x00,0x00,0x31,0x94};
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[0]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[1]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[2]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[3]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[4]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[5]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[6]);
					while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);
					USART_SendData(USART2, buf[7]);
//					count_500ms=3;
				}
				else if(count_500ms==4)
				{
					uint8_t esp_cipsend[17]={'A','T','+','C','I','P','S','E','N','D','=','0',',','1','9',0x0D,0X0A};
					u8 checksum=0;
					u8 ii=0;
					u8 *p;
					u8 E2promRead_Buffer[13];
					for(ii=0;ii<17;ii++)
					{
						while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
						USART_SendData(UART4, esp_cipsend[ii]);
					}
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					
					delay_ms(2);
					AT24CXX_Read(0,E2promRead_Buffer,13);
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					USART_SendData(UART4, 0xec);
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					USART_SendData(UART4, 0x91);
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					USART_SendData(UART4, 0x01);
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					USART_SendData(UART4, 0x11);
					for(ii=0;ii<12;ii++)
					{
						while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
						USART_SendData(UART4, E2promRead_Buffer[ii]);
					}
					E2promRead_Buffer[12]=E2promRead_Buffer[12]+0xec+0x91+0x01+0x11;
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					USART_SendData(UART4, E2promRead_Buffer[12]);
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					USART_SendData(UART4, 0x0D);
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					USART_SendData(UART4, 0X0A);
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					
				}
				else if(count_500ms==5)
				{
//					u8 checksum=0;
//					u8 ii=0;
//					u8 *p;
//					u8 E2promRead_Buffer[13];
//					AT24CXX_Read(0,E2promRead_Buffer,13);
//					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
//					USART_SendData(UART4, 0xec);
//					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
//					USART_SendData(UART4, 0x91);
//					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
//					USART_SendData(UART4, 0x01);
//					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
//					USART_SendData(UART4, 0x11);
//					for(ii=0;ii<12;ii++)
//					{
//						while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
//						USART_SendData(UART4, E2promRead_Buffer[ii]);
//					}
//					E2promRead_Buffer[12]=E2promRead_Buffer[12]+0xec+0x91+0x01+0x11;
//					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
//					USART_SendData(UART4, E2promRead_Buffer[12]);
//					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
//					USART_SendData(UART4, 0x0D);
//					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
//					USART_SendData(UART4, 0X0A);
//					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
				}
				
				
			}//500ms �жϽ���
			
			if(is_wr_ad9361_freq_to_e2prom)
			{
				is_wr_ad9361_freq_to_e2prom=false;
				wr_ad9361_freq_to_e2prom(freq_WrToE2prom);
			}
			if(is_wr_ad9361_sv_number_to_e2prom)
			{
				is_wr_ad9361_sv_number_to_e2prom=false;
				wr_ad9361_sv_number_to_e2prom(sv_number_WrToE2prom);
//								AT24CXX_Read(0,E2promRead_Buffer,13);
//								
//								AT24CXX_Read(0,E2promRead_Buffer_1,13);		
			}
			if(is_wr_ad9361_amplititude_to_e2prom)
			{
				is_wr_ad9361_amplititude_to_e2prom=false;
				wr_ad9361_amplititude_to_e2prom(amplititude_WrToE2prom);
			}
			
			if(is_ublox_data_NavLLH_catched)
			{
				is_ublox_data_NavLLH_catched=false;
				
				//
				for(ii=0;ii<17;ii++)
				{
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					USART_SendData(UART4, esp_cipsend_NavLLH[ii]);
				}
				delay_ms(2);
				for(ii=0;ii<Usart2SBUFCount;ii++)
				{
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					USART_SendData(UART4, Usart2SBUF[ii]);
				}
				
				
			}
			if(is_ublox_data_Navsvinfo_catched)
			{
				is_ublox_data_Navsvinfo_catched=false;
				
				for(ii=0;ii<17;ii++)
				{
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					USART_SendData(UART4, esp_cipsend_Navsvinfo[ii]);
				}
				delay_ms(2);
				for(ii=0;ii<Usart2SBUFCount;ii++)
				{
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					USART_SendData(UART4, Usart2SBUF[ii]);
				}
			}
			if(is_ublox_data_NavTimegps_catched)
			{
				is_ublox_data_NavTimegps_catched=false;
				
				for(ii=0;ii<18;ii++)
				{
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					USART_SendData(UART4, esp_cipsend_NavTimegps[ii]);
				}
				delay_ms(2);
				
				for(ii=0;ii<Usart2SBUFCount;ii++)
				{
					while(USART_GetFlagStatus(UART4,USART_FLAG_TC)!=SET);
					USART_SendData(UART4, Usart2SBUF[ii]);
				}
			}

		}//while����
}
/*************************************************
Function: void EXTI9_5_IRQHandler(void) external interrupt request handler   
Description:          
Input: ��                              
Output:��                              
Return:��                              
*************************************************/  
bool PullinEnd=false;
int initial_counter=0;
short dac_offset=0;
void EXTI9_5_IRQHandler(void)//PA8
{
	int32_t tempF = 0;
	short toWrite=0;
	double tempDouble=0;
	uint8_t temp = 0xff;
	
  if(SET == EXTI_GetITStatus(EXTI_Line8))
  {    
		
    EXTI_ClearFlag(EXTI_Line8);
		OneppsFlag = BYTE_TRUE;   //OnePPS flag set TRUE	
    if(isSystemInitEnd) initial_counter++;
		if(initial_counter<20) return;		
		if(PullinEnd==false)
		{ 
			tempF =(FPGA_read(ONEPPS_INTERVAL_HIGH_ADDR)<<16 | FPGA_read(ONEPPS_INTERVAL_LOW_ADDR));
			
			if(tempF > PL_TX_FREQ)
			{
				
				tempF-=PL_TX_FREQ;				
				
				if(tempF<1) { PullinEnd=true; FPGA_write(PSEUDOLITE_CTRL_ADDR,0x1);}
				
				if(CurrentRefValue>25 )CurrentRefValue-=25;
				else CurrentRefValue=0;
				FPGA_write(DAC_REG_DATA, CurrentRefValue);
			}
			else 
			{
				
				tempF=PL_TX_FREQ-tempF;	
				if(tempF<1) { PullinEnd=true; FPGA_write(PSEUDOLITE_CTRL_ADDR,0x1);}
        if(CurrentRefValue<60000 ) CurrentRefValue+=25;
				FPGA_write(DAC_REG_DATA, CurrentRefValue);
			}
	  }
		else //(PullinEnd==true)
		{
			   yk =(FPGA_read(ONEPPS_INTERVAL_HIGH_ADDR)<<16 | FPGA_read(ONEPPS_INTERVAL_LOW_ADDR));				 
				 xk = (FPGA_read(ONEPPS_OFFSET_HIGH) << 16) | FPGA_read(ONEPPS_OFFSET_LOW);
			   if(xk>0 && yk <= PL_TX_FREQ)	
				 {
					 //if(dac_offset<0) dac_offset=0;
					 dac_offset++;			  
				 }
				 else if(xk<0 && yk >= PL_TX_FREQ)	
				 {
					 //if(dac_offset>0) dac_offset=0;
					 dac_offset--;
				 }
				 else if(yk > PL_TX_FREQ)
			   {
					CurrentRefValue-=10;
			   }
				 else if(yk < PL_TX_FREQ)
				 {CurrentRefValue+=10;}
				 
		     toWrite=CurrentRefValue+dac_offset;		     
		     xk_1 = xk;
				 
		     FPGA_write(DAC_REG_DATA, toWrite);			
		}

    EXTI_ClearITPendingBit(EXTI_Line8);
  }  
}
//void EXTI0_IRQHandler(void)//
//{
//  if(SET == EXTI_GetITStatus(EXTI_Line0))
//  {    
//    EXTI_ClearFlag(EXTI_Line0);
////	OneppsFlag = BYTE_TRUE;   //OnePPS flag set TRUE
//    EXTI_ClearITPendingBit(EXTI_Line0);
//  }  
//}


/*************************************************
Function: void UART4_IRQHandler(void) uart4 handler   
Description:          
Input: ?T                              
Output:?T                              
Return:?T                              
*************************************************/  
uint8_t checksum = 0;

void UART4_IRQHandler(void)
{
	uint8_t temp = 0;
	uint16_t temp1 = 0;
	uint32_t temp2 = 0;
	uint32_t temp32=0;
	uint64_t freq = 0;
	uint8_t factor =100;
	uint8_t checksum2 =0;
	uint8_t ParaBytes[4];
	u8 E2promRead_Buffer[13];
	u8 E2promRead_Buffer_1[13];
	bool ret = 0;
	if(USART_GetITStatus(UART4,  USART_IT_RXNE) != RESET)
	{
		USART_ClearITPendingBit(UART4, USART_IT_RXNE);
		temp = USART_ReceiveData(UART4);		

		if(frameheadfound == BYTE_TRUE)
		{	
			SBUF[bufcount] = temp;
			if(bufcount >= 7)
			{
				bufcount = 0;
				if(checksum == SBUF[7])
				{
					if(SBUF[1]==0X90)
					{
						switch(SBUF[2])
						{
							case 0x01:
								ret = set_sv_number(SBUF[6]);   //���Ǻţ�
								sv_number_WrToE2prom=0;	
								sv_number_WrToE2prom=SBUF[6];
								is_wr_ad9361_sv_number_to_e2prom=true;
								break;
							case 0x02: 
								temp1 = ((SBUF[5]<<8)&0xff00)+SBUF[6];
								amplititude_WrToE2prom=0;	
								amplititude_WrToE2prom=((SBUF[5]<<8)&0xff00)+SBUF[6];
								ret = set_tx_amplititude(temp1);    //����
								is_wr_ad9361_amplititude_to_e2prom=true;
								break;
							case 0x03: 
								temp2 = SBUF[3];
								temp2 = ((temp2<<8)&0xff00)+SBUF[4];
								temp2 = ((temp2<<8)&0xffff00)+SBUF[5];
								temp2 = ((temp2<<8)&0xffffff00)+SBUF[6];
								freq = temp2*factor; 
								freq_WrToE2prom=0;
								freq_WrToE2prom=temp2;
								temp2 = ad9361_set_tx_lo_freq(ad9361_phy, freq);    //Ƶ��
								is_wr_ad9361_freq_to_e2prom=true;
								break;
							//case 0x04: ;
							default: break;
						}
//						checksum2 = 0x8A+SBUF[2]+SBUF[3]+SBUF[4]+SBUF[5]+SBUF[6];
//						USART_SendData(UART4, 0xEB);
//						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
//						USART_SendData(UART4, 0x9F);
//						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
//						USART_SendData(UART4, SBUF[2]);
//						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
//						USART_SendData(UART4, SBUF[3]);
//						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
//						USART_SendData(UART4, SBUF[4]);
//						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
//						USART_SendData(UART4, SBUF[5]);
//						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
//						USART_SendData(UART4, SBUF[6]);
//						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
//						USART_SendData(UART4, checksum2);
//						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
					}
					else if(SBUF[1]==0X6F)
					{
						switch(SBUF[2])
						{
							case 0x00: 
								break;
							case 0x01: 
								temp1 = FPGA_read(SV_NUMBER_ADDR);
								ParaBytes[0] = temp1&0xff;
								ParaBytes[1] = 0;
								ParaBytes[2] = 0;
								ParaBytes[3] = 0;
								break;
							case 0x02: 
								temp1 = FPGA_read(TX_DATA_AMPLITUDE_ADDR);
								ParaBytes[0] = temp1&0xff;
								ParaBytes[1] = (temp1&0xff00)>>8;
								ParaBytes[2] = 0;
								ParaBytes[3] = 0;
								break;
							case 0x03: 
								temp2 = ad9361_get_tx_lo_freq(ad9361_phy,&freq);
								freq = freq/100;
								ParaBytes[0] = freq&0xff;
								ParaBytes[1] = (freq&0xff00)>>8;
								ParaBytes[2] = (freq&0xff0000)>>16;
								ParaBytes[3] = (freq&0xff000000)>>24;
								break;
							default: break;
						}
						checksum2 = 0x4B+SBUF[2]+ParaBytes[3]+ParaBytes[2]+ParaBytes[1]+ParaBytes[0];
						USART_SendData(UART4, 0xEB);
						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
						USART_SendData(UART4, 0x60);
						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
						USART_SendData(UART4, SBUF[2]);
						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
						USART_SendData(UART4, ParaBytes[3]);
						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
						USART_SendData(UART4, ParaBytes[2]);
						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
						USART_SendData(UART4, ParaBytes[1]);
						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
						USART_SendData(UART4, ParaBytes[0]);
						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
						USART_SendData(UART4, checksum2);
						while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
							
					}
					ParaBytes[0]=0;ParaBytes[1]=0;ParaBytes[2]=0;ParaBytes[3]=0;
					temp1 =0;
					temp2 = 0;
					checksum = 0;
					checksum2 = 0;
				}
				SBUF[0]=0;SBUF[1]=0;SBUF[2]=0;SBUF[3]=0;SBUF[4]=0;SBUF[5]=0;SBUF[6]=0;SBUF[7]=0;
				frameheadfound = BYTE_FALSE;
			}
			checksum += temp;
			temp = 0;
			bufcount++;
		}
		else if(temp == 0xEB)
		{
				frameheadfound = BYTE_TRUE;
				bufcount=0;
				SBUF[bufcount] = temp;
				checksum=0;
				checksum += temp;
				bufcount++;
				temp = 0;
		}		
	}
}
/*��ʱ���նϴ�������
wangjiabo
*/			
//void TIM3_IRQHandler(void)
//{
//	if(TIM_GetITStatus(TIM3,TIM_IT_Update)!= RESET)
//	{
//	//	TIM_ClearITPendingBit(TIM3,TIM_FLAG_Update);
//		TIM_ClearFlag(TIM3,TIM_FLAG_Update);
//		//GPIO_ToggleBits(GPIOA,GPIO_Pin_1);
//		
//	}
//}


void USART2_IRQHandler(void)
{
	uint8_t temp = 0;
	if(USART_GetITStatus(USART2,  USART_IT_RXNE) != RESET)
	{
		USART_ClearITPendingBit(USART2, USART_IT_RXNE);
		temp = USART_ReceiveData(USART2);
//		USART2_ReceiveBuf[USART2_ReceiveCount]=temp;
//		USART2_ReceiveCount++;
		
		if(is_ublox_0xb5found)
		{
			if(is_ublox_0x62found)
			{
				if(is_ublox_0x01found)
				{
					if(is_ublox_ID_NavLLHFound)
					{
						if(Usart2SBUFCount==4)
						{
							DataLength=temp;
							Usart2SBUF[Usart2SBUFCount]=temp;
							Usart2SBUFCount++;
						}
						else if(Usart2SBUFCount==5)
						{
							DataLength=DataLength+((temp<<8)&0xff00);
							Usart2SBUF[Usart2SBUFCount]=temp;
							Usart2SBUFCount++;
						}
						else if(Usart2SBUFCount<DataLength+8)
						{
							Usart2SBUF[Usart2SBUFCount]=temp;
							Usart2SBUFCount++;
							
							if(Usart2SBUFCount==DataLength+8)
							{
								is_ublox_data_NavLLH_catched=true;
								is_ublox_0xb5found=false;
								is_ublox_0x62found=false;
								is_ublox_0x01found=false;
								is_ublox_ID_NavLLHFound=false;
															
							}
						
						}
					}
					else if(is_ublox_ID_NavsvinfoFound)
					{
						if(Usart2SBUFCount==4)
						{
							DataLength=temp;
							Usart2SBUF[Usart2SBUFCount]=temp;
							Usart2SBUFCount++;
						}
						else if(Usart2SBUFCount==5)
						{
							DataLength=DataLength+((temp<<8)&0xff00);
							Usart2SBUF[Usart2SBUFCount]=temp;
							Usart2SBUFCount++;
						}
						else if(Usart2SBUFCount<DataLength+8)
						{
							Usart2SBUF[Usart2SBUFCount]=temp;
							Usart2SBUFCount++;
							if(Usart2SBUFCount==DataLength+8)
							{
								is_ublox_data_Navsvinfo_catched =true;
								is_ublox_0xb5found=false;
								is_ublox_0x62found=false;
								is_ublox_0x01found=false;
								is_ublox_ID_NavsvinfoFound=false;
							}
						}
					}
					else if(is_ublox_ID_NavTimegpsFound)
					{
						if(Usart2SBUFCount==4)
						{
							DataLength=temp;
							Usart2SBUF[Usart2SBUFCount]=temp;
							Usart2SBUFCount++;
						}
						else if(Usart2SBUFCount==5)
						{
							DataLength=DataLength+((temp<<8)&0xff00);
							Usart2SBUF[Usart2SBUFCount]=temp;
							Usart2SBUFCount++;
						}
						else if(Usart2SBUFCount<DataLength+8)
						{
							Usart2SBUF[Usart2SBUFCount]=temp;
							Usart2SBUFCount++;
							
							if(Usart2SBUFCount==DataLength+8)
							{
								is_ublox_data_NavTimegps_catched=true;
								is_ublox_0xb5found=false;
								is_ublox_0x62found=false;
								is_ublox_0x01found=false;
								is_ublox_ID_NavTimegpsFound=false;
							}
						}
					}
					else if(temp==0x02)
					{
						is_ublox_ID_NavLLHFound=true;
						Usart2SBUF[Usart2SBUFCount]=temp;
						Usart2SBUFCount++;
						
					}
					else if(temp==0x20)
					{
						is_ublox_ID_NavsvinfoFound=true;
						Usart2SBUF[Usart2SBUFCount]=temp;
						Usart2SBUFCount++;
					}
					else if(temp==0x30)
					{
						is_ublox_ID_NavTimegpsFound=true;
						Usart2SBUF[Usart2SBUFCount]=temp;
						Usart2SBUFCount++;
					}
					else
					{
						is_ublox_0xb5found=false;
						is_ublox_0x62found=false;
						is_ublox_0x01found=false;
					}
					
				}
				else if(temp==0x01)
				{
					is_ublox_0x01found=true;
					Usart2SBUF[Usart2SBUFCount]=temp;
					Usart2SBUFCount++;
				}
				else
				{
					is_ublox_0xb5found=false;
					is_ublox_0x62found=false;
				}
			}
			else if(temp==0x62)
			{
				is_ublox_0x62found=true;
				Usart2SBUF[Usart2SBUFCount]=temp;
				Usart2SBUFCount++;
			}
			else
			{
				is_ublox_0xb5found=false;
			}
		}
		else if(temp==0xb5)
		{
			is_ublox_0xb5found=true;
			Usart2SBUFCount=0;
			Usart2SBUF[Usart2SBUFCount]=temp;
			Usart2SBUFCount++;
		}
		temp=0;
	}
}

