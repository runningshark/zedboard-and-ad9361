clc;
clear;
close all;
warning off;

seq_sync = tx_gen_m_seq([1 0 0 0 0 0 1]);
frame_sync = tx_modulate(seq_sync, 'BPSK');
rand_bits=randi([0 1],1,5000);
mod_symbols = tx_modulate(rand_bits, 'BPSK');
frame_bits = insert_pilot(mod_symbols);
uw = uw_generate(36);
trans_bits=[frame_sync uw frame_bits];
fir = rcosdesign(1,128,4);
tx_frame = upfirdn(trans_bits,fir,4);

%% send to yunsdr
yunsdr_init.samp=20e6;      %sample freq 4e6~61.44e6
yunsdr_init.bw=40e6;        %fir bandwidth 250e3~56e6
yunsdr_init.freq=2350e6;    %rx LO freq 70e6~6000e6
yunsdr_init.tx_att1=5e3;   %tx att ch1 0~90e3 mdB
yunsdr_init.tx_att2=5e3;    %tx att ch2 0~90e3 mdB
yunsdr_init.rcount=10;      %refclkin/rcount = 26MHz/ncount
yunsdr_init.ncount=26;      %
yunsdr_init.ref=0;          %1=external ref 0=internal ref
yunsdr_init.vco_cal=1;      %vco=1 refclk of ad9361 from auxdac
yunsdr_init.aux_dac1=0;     %aux_dac 0~3000mv
yunsdr_init.fdd_tdd=1;      %fdd=1,tdd=0
yunsdr_init.trx_sw=1;       %fdd mode trx=1; tdd trx=1 when tx mode
yunsdr_init.tx_chan=1;      %1=tx1;2=tx2;3=tx1&tx2
[ret,rem]=send_to_yunsdr(tx_frame,yunsdr_init);