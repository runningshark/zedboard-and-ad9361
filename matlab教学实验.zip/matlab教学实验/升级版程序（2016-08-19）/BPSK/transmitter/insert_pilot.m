function out_signal = insert_pilot(mod_symbols)

Nr=100;
len_mod=mod(length(mod_symbols),Nr);
signal=mod_symbols(1:length(mod_symbols)-len_mod);
Ns=length(signal)/Nr;

temp=reshape(signal,Ns,Nr);
pilot=tx_modulate([1 0 1 0 1 0 1 0], 'QPSK');
pilot=repmat(ones(1,4),Ns,1);
% pilot=pilot.*exp(-1i*pi/4);
last=[temp pilot];
last=last';
bo=last(:)';
if len_mod ~= 0
    remain=mod_symbols(end-len_mod+1:end); 
    out_signal=[bo remain];
else
    out_signal=bo;
end

end

