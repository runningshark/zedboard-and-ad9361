function out_signal = rx_delete_pilot(signal)
Nr=100+4;
Ns=length(signal)/Nr;
signal=reshape(signal,Nr,Ns);
signal=signal';
N=size(signal,2);
out_signal=[];
for i=1:N-4
    out_signal1=signal(:,i);
    out_signal=[out_signal out_signal1];
end
out_signal=out_signal(:)';

end

