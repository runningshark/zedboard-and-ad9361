function [signal,phase_curve] = rx_phase_track(signal)
local_pilot=ones(1,4)-2;
idx=0;
N=100+4;
phase_curve=0;
for i=1:N:length(signal)-N
    temp=signal(i:(i+N-1));
    rx_pilot=temp(N-3:end);
    [~,ang]=rx_phase_sync(rx_pilot,local_pilot);
    idx=idx+1;
    phase_curve(idx)=ang;
    signal(i+N:end)=signal(i+N:end).*exp(-1i*ang);
end
