clc;
clear;
close all;
warning off;
set(0,'defaultfigurecolor','w');

%% init yunsdr
yunsdr_init.samp=20e6;     %sample freq 4e6~61.44e6
yunsdr_init.bw=40e6;       %fir bandwidth 250e3~56e6
yunsdr_init.freq=2350e6;   %rx LO freq 7s0e6~6000e6
yunsdr_init.rxgain1=25;    %rx gain ch1 0~76
yunsdr_init.rxgain2=20;    %rx gain ch2 0~76
yunsdr_init.rcount=10;     %refclkin/rcount = 26MHz/ncount
yunsdr_init.ncount=26;     %
yunsdr_init.ref=0;         %1=external ref 0=internal ref
yunsdr_init.vco_cal=1;     %vco=1 refclk of ad9361 from auxdac
yunsdr_init.aux_dac1=0;    %aux_dac 0~3000mv
yunsdr_init.fdd_tdd=1;     %fdd=1,tdd=0
yunsdr_init.trx_sw=1;      %fdd mode trx=1; tdd trx=1 when tx mode
yunsdr_init.rx_chan=1;     %1=rx1;2=rx2;3=rx1&rx2
yunsdr_init.buff=256*1024; %receive data in Byte

seq_sync = tx_gen_m_seq([1 0 0 0 0 0 1]);
uw = uw_generate(36);
local_sync = tx_modulate(seq_sync, 'BPSK');
%% connect to yunsdr
link = connect_to_yunsdr(yunsdr_init);
cyc=0;
while(cyc<5)
%% receive samples
rx_samples_yunsdr=receive_from_yunsdr(yunsdr_init,link);
%-----ƥ���˲�-----%
fir = rcosdesign(1,128,4);
rx_sig_filter = upfirdn(rx_samples_yunsdr,fir,1);
%-----��һ��-----%
c1=max([abs(real(rx_sig_filter')),abs(imag(rx_sig_filter'))]);
rx_sig_norm=rx_sig_filter ./c1;
%-----��ʱͬ��,4ѡ1������-----%
[time_error,rx_sig_down]=rx_timing_recovery(rx_sig_norm);
% rx_sig_down=rx_sig_norm(1:4:end)';
%-----����ͬ��-----%
[rx_frame,cor_abs,th_max]=rx_package_search(rx_sig_down,local_sync,5363); 
%-----��Ƶƫ����-----%
coarse_sync_seq=rx_frame(1:8);
[deltaf1,out_signal1] = rx_freq_sync(coarse_sync_seq,2,rx_frame);
%-----��1�ξ�Ƶƫ����-----%
fine_sync_seq_1=out_signal1(1:127);
[deltaf2,out_signal2] = rx_freq_sync(fine_sync_seq_1,2,out_signal1);
%-----��2�ξ�Ƶƫ����-----%
fine_sync_seq_2=out_signal2(1:120);
[deltaf3,out_signal3] = rx_freq_sync(local_sync,2,out_signal2);
deltaf=deltaf1+deltaf2+deltaf3;
%-----��ʼ��λ����-----%
[out_signal4,ang] = rx_phase_sync(out_signal3,local_sync(1:80));
% [y] = rx_mmse_fde(out_signal4(128:end),uw);
y=out_signal4(127+36+1:end);
%-----��λ����-----%
[out_signal5,phase_curve] = rx_phase_track(y);
%-----��Ƶɾ��-----%
out_signal6 = rx_delete_pilot(out_signal5);
%-----qpsk���-----%
[soft_bits_out,evm] = rx_qpsk_demod(out_signal6);
%% display
figure(1);clf;
subplot(211);
plot(real(rx_samples_yunsdr),'r');
hold on;
plot(imag(rx_samples_yunsdr),'b');
grid on;
title('���ն�ʱ���ź�');
subplot(223);
plot(real(out_signal6),imag(out_signal6),'b.');
title('ͬ������ͼ');
axis([-1.2 1.2 -1.2 1.2]);
axis square;
cyc=cyc+1;
% debug;
pause(0.001);
end
%% disconnect
stop_connect_yunsdr(link);