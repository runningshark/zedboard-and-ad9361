function res=stop_connect_yunsdr(link)

    %% send handshake2 cmd to stop adc thread
    handshake=[hex2dec('ff') 1 hex2dec('17') hex2dec('f0') 0 0 0 0];
    fwrite(link.ctrl_link,handshake,'uint8');
    %% close all link
    fclose(link.data_link);
    delete(link.data_link);
    clear link.data_link;
    fclose(link.ctrl_link);
    delete(link.ctrl_link);
    clear link.ctrl_link;
%     clc;
    disp('*---Network link has been disconnected!---*');
    res='*---Network link has been disconnected!---*';
    
end
