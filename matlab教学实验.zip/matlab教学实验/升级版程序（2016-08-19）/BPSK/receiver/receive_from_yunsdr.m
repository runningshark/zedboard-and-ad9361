function data_rec_yunsdr = receive_from_yunsdr(yunsdr_init,link)
ctrl_link=link.ctrl_link;
data_link=link.data_link;
%% send handshake2 cmd to start adc thread
size_hex=dec2hex(yunsdr_init.buff,8);
handshake=[2 1 hex2dec('17') hex2dec('f0') hex2dec(size_hex(7:8)) hex2dec(size_hex(5:6)) hex2dec(size_hex(3:4)) hex2dec(size_hex(1:2))];
fwrite(ctrl_link,handshake,'uint8');
%% read 256*1024 bytes data from zing
data = fread(data_link,yunsdr_init.buff,'uint8');
%% receive
datah=data(2:2:end);
datal=data(1:2:end);
datah_hex=dec2hex(datah,2);
datal_hex=dec2hex(datal,2);
data_hex(:,1:2)=datah_hex;
data_hex(:,3:4)=datal_hex;
dataun=hex2dec(data_hex);
datain=dataun-(dataun>32767)*65536;
if yunsdr_init.rx_chan==1
    a1=datain(1:2:end);
    a2=datain(2:2:end);
    a3=zeros(1,length(a1));
    a4=zeros(1,length(a1));
elseif yunsdr_init.rx_chan==2
    a3=datain(1:2:end);
    a4=datain(2:2:end);
    a1=zeros(1,length(a3));
    a2=zeros(1,length(a3));
elseif yunsdr_init.rx_chan==3
    a1=datain(1:4:end);
    a2=datain(2:4:end);
    a3=datain(3:4:end);
    a4=datain(4:4:end);
end

data_rec_chan1=a1+1i*a2;
data_rec_chan2=a3+1i*a4;

if  yunsdr_init.rx_chan==1
    data_rec_yunsdr=data_rec_chan1;
elseif yunsdr_init.rx_chan==2
    data_rec_yunsdr=data_rec_chan2;
end
data_rec_yunsdr=data_rec_yunsdr(:,1);

end