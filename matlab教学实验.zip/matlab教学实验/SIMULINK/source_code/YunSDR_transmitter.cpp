/* Copyright 2003-2004 The MathWorks, Inc. */

// *******************************************************************
// **** To build this mex function use: mex sfun_cppcount_cpp.cpp ****
// *******************************************************************
#include <WINSOCK2.H>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <conio.h>

#pragma comment(lib,"ws2_32.lib")

#define S_FUNCTION_LEVEL 2
#define S_FUNCTION_NAME  YunSDR_transmitter
// Need to include simstruc.h for the definition of the SimStruct and
// its associated macro definitions.
#include "simstruc.h"

#define INPUT_DATA_WIDTH  2048
#define OUTPUT_DATA_WIDTH 2048

char _buf[8192]={0};
char *buf=_buf;

void YunsdrStartSocket(SimStruct *S);
void YunsdrSendCmd(SimStruct *S);
void YunsdrCloseSocket(SimStruct *S);

#define IS_PARAM_DOUBLE(pVal) (mxIsNumeric(pVal) && !mxIsLogical(pVal) &&\
!mxIsEmpty(pVal) && !mxIsSparse(pVal) && !mxIsComplex(pVal) && mxIsDouble(pVal))
// Function: mdlInitializeSizes ===============================================
// Abstract:
//    The sizes information is used by Simulink to determine the S-function
//    block's characteristics (number of inputs, outputs, states, etc.).
static void mdlInitializeSizes(SimStruct *S)
{
    ssSetNumSFcnParams(S, 10);
    // Parameter mismatch will be reported by Simulink
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        return;
    }
    // Specify I/O
    if (!ssSetNumInputPorts(S, 2)) return;
    ssSetInputPortWidth(S, 0, INPUT_DATA_WIDTH);
    ssSetInputPortWidth(S, 1, INPUT_DATA_WIDTH);
     
    ssSetInputPortDirectFeedThrough(S, 0, 1);
    ssSetInputPortDirectFeedThrough(S, 1, 1);
    
    if (!ssSetNumOutputPorts(S,0)) return;
//     ssSetOutputPortWidth(S, 0, OUTPUT_DATA_WIDTH);
//     ssSetOutputPortWidth(S, 1, OUTPUT_DATA_WIDTH);
    ssSetNumSampleTimes(S, 1);
    ssSetNumPWork(S, 4);
}
// Function: mdlInitializeSampleTimes =========================================
// Abstract:
//   This function is used to specify the sample time(s) for your
//   S-function. You must register the same number of sample times as
//   specified in ssSetNumSampleTimes.
static void mdlInitializeSampleTimes(SimStruct *S)
{
//     ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
    ssSetSampleTime(S, 0, -1);
    ssSetOffsetTime(S, 0, 0.0);
    ssSetModelReferenceSampleTimeDefaultInheritance(S); 
}
// Function: mdlStart =======================================================
// Abstract:
//   This function is called once at start of model execution. If you
//   have states that should be initialized once, this is the place
//   to do it.
#define MDL_START
static void mdlStart(SimStruct *S)
{
    YunsdrStartSocket(S);    
    YunsdrSendCmd(S);
}
// Function: mdlOutputs =======================================================
// Abstract:
//   In this function, you compute the outputs of your S-function
//   block.
static void mdlOutputs(SimStruct *S, int_T tid)
{
    SOCKET *pSendSocketData = static_cast<SOCKET *>(ssGetPWork(S)[2]);
    sockaddr_in *pRecvAddrData = static_cast<sockaddr_in *>(ssGetPWork(S)[3]);
    
    InputRealPtrsType u0 = ssGetInputPortRealSignalPtrs(S, 0);
    InputRealPtrsType u1 = ssGetInputPortRealSignalPtrs(S, 1);
    
//     real_T *signal_i = ssGetOutputPortRealSignal(S, 0);
//     real_T *signal_q = ssGetOutputPortRealSignal(S, 1);
    
    int InputNum0 = ssGetInputPortWidth(S, 0);
    int InputNum1 = ssGetInputPortWidth(S, 1);
    
//     InputNum0 = 4096 
//     for(int i=0;i<InputNum0;i++)
//     {
//         (double)signal_i[i] = *u0[i];
//         (double)signal_q[i] = *u1[i];
//     }
   
    for (int i=0;i<8192;i+=4)
    {
        (*(short*)(buf+i)) = (short)((*u0)[i/4]);
        (*(short*)(buf+i+2)) = (short)((*u1)[i/4]);
    }
    
    sendto(*pSendSocketData,buf, 8192, 0, (SOCKADDR *)pRecvAddrData, sizeof(sockaddr_in));
    
//     FILE *fp;
//     fp = fopen("tone.dat","wb");
//     fwrite(buf, 1, 8192, fp);
//     fclose(fp);
    
}
// Function: mdlTerminate =====================================================
// Abstract:
//   In this function, you should perform any actions that are necessary
//   at the termination of a simulation.  For example, if memory was
//   allocated in mdlStart, this is the place to free it.
static void mdlTerminate(SimStruct *S)
{
    YunsdrCloseSocket(S);
}
/******************************************************************************/
/*user define function
/******************************************************************************/
void YunsdrStartSocket(SimStruct *S)
{
    real_T *para0 = mxGetPr(ssGetSFcnParam(S,0));
    real_T *para1 = mxGetPr(ssGetSFcnParam(S,1));
    real_T *para2 = mxGetPr(ssGetSFcnParam(S,2));
    
    WSADATA wsaCmd, wsaData;
    SOCKET *pSendSocketCmd = new SOCKET;
    SOCKET *pSendSocketData = new SOCKET;
    *pSendSocketCmd = INVALID_SOCKET;
    *pSendSocketData = INVALID_SOCKET;
    sockaddr_in *pRecvAddrCmd = new sockaddr_in;
    sockaddr_in *pRecvAddrData = new sockaddr_in;
    
    unsigned short PortCmd = *para1;
    unsigned short PortData = *para2;
    
    WSAStartup(MAKEWORD(2,2), &wsaCmd);
    WSAStartup(MAKEWORD(2,2), &wsaData);
    
    *pSendSocketCmd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    *pSendSocketData = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    
    pRecvAddrCmd->sin_family = AF_INET;
    pRecvAddrCmd->sin_port = htons(PortCmd);
    pRecvAddrCmd->sin_addr.s_addr = inet_addr("192.168.1.10");
    pRecvAddrData->sin_family = AF_INET;
    pRecvAddrData->sin_port = htons(PortData);
    pRecvAddrData->sin_addr.s_addr = inet_addr("192.168.1.10");
    
    ssSetPWorkValue(S, 0, pSendSocketCmd);
    ssSetPWorkValue(S, 1, pRecvAddrCmd);
    ssSetPWorkValue(S, 2, pSendSocketData);
    ssSetPWorkValue(S, 3, pRecvAddrData);
    
    connect(*pSendSocketData, (SOCKADDR*)pRecvAddrData, sizeof(sockaddr_in));
    
}

void YunsdrSendCmd(SimStruct *S)
{
    SOCKET *pSendSocket = static_cast<SOCKET *>(ssGetPWork(S)[0]);
    sockaddr_in *pRecvAddr = static_cast<sockaddr_in *>(ssGetPWork(S)[1]);
    
    /*tx_freq select*/ 
    real_T *para3 = mxGetPr(ssGetSFcnParam(S,3));
    unsigned double tx_freq = (*para3)*1e6;
    unsigned int cmd_buf_tx_freq[2] = {0,0};
    cmd_buf_tx_freq[0] = 0xF0220000|(3<<8)|((tx_freq)>>32);
    cmd_buf_tx_freq[1] = (tx_freq)&0x00FFFFFFFFUL;
    sendto(*pSendSocket, (char *)&cmd_buf_tx_freq, sizeof(cmd_buf_tx_freq),0,(SOCKADDR*)pRecvAddr, sizeof(sockaddr_in));
    /*tx_bw select*/
    real_T *para4 = mxGetPr(ssGetSFcnParam(S,4));
    unsigned int bw=(*para4)*1e6;
    unsigned int cmd_buf_tx_bw[2]={0,0};
    cmd_buf_tx_bw[0] = 0xF0220000|(7<<8);
    cmd_buf_tx_bw[1] = bw;
    sendto(*pSendSocket, (char *)&cmd_buf_tx_bw, sizeof(cmd_buf_tx_bw),0,(SOCKADDR*)pRecvAddr, sizeof(sockaddr_in));
    /*tx_samp select*/
    real_T *para5 = mxGetPr(ssGetSFcnParam(S,5));
    unsigned long int sample_rate=(*para5)*1e6;
    unsigned int cmd_buf_tx_sample[2]={0,0};
    cmd_buf_tx_sample[0] = 0xF0220000|(5<<8);
    cmd_buf_tx_sample[1] = sample_rate;
    sendto(*pSendSocket, (char *)&cmd_buf_tx_sample, sizeof(cmd_buf_tx_sample),0,(SOCKADDR*)pRecvAddr, sizeof(sockaddr_in));
    /*tx_gain select*/
    real_T *para6 = mxGetPr(ssGetSFcnParam(S,6));
    long int gain=(*para6);
    unsigned int cmd_buf_chan1[2]={0,0};
    cmd_buf_chan1[0] = 0xF0220000 | (9<<8); //set tx vga
    cmd_buf_chan1[1] = gain;
    sendto(*pSendSocket, (char *)&cmd_buf_chan1, sizeof(cmd_buf_chan1),0,(SOCKADDR*)pRecvAddr, sizeof(sockaddr_in));
    unsigned int cmd_buf_chan2[2]={0,0};
    cmd_buf_chan2[0] = 0xF0220000 | (11<<8); //set tx vga
    cmd_buf_chan2[1] = gain;
    sendto(*pSendSocket, (char *)&cmd_buf_chan2, sizeof(cmd_buf_chan2),0,(SOCKADDR*)pRecvAddr, sizeof(sockaddr_in));
    /*tx_channel select*/
    real_T *para7 = mxGetPr(ssGetSFcnParam(S,7));
    unsigned int channel=*para7;
    unsigned int cmd_buf[2]={0,0};
    cmd_buf[0] = 0xF0200000|(channel&0x03);
    sendto(*pSendSocket, (char *)&cmd_buf, sizeof(cmd_buf),0,(SOCKADDR*)pRecvAddr, sizeof(sockaddr_in));
    real_T *para8 = mxGetPr(ssGetSFcnParam(S,8));
    /*ref select*/
    unsigned int ref_select=*para8-1;
    unsigned int cmd_buf_ref[2]={0,0};
    cmd_buf_ref[0] = 0xF0220000|(40<<8);
    cmd_buf_ref[1] = ref_select;
    sendto(*pSendSocket, (char *)&cmd_buf_ref, sizeof(cmd_buf_ref),0,(SOCKADDR*)pRecvAddr, sizeof(sockaddr_in));
    /*vco_cal_select*/
    unsigned int vco_cal=1;
    unsigned int cmd_buf_vco_cal[2]={0,0};
    cmd_buf_vco_cal[0] = 0xF0220000|(41<<8);
    cmd_buf_vco_cal[1] = vco_cal;
    sendto(*pSendSocket, (char *)&cmd_buf_vco_cal, sizeof(cmd_buf_vco_cal),0,(SOCKADDR*)pRecvAddr, sizeof(sockaddr_in));
    real_T *para9 = mxGetPr(ssGetSFcnParam(S,9));
    /*fdd or tdd select*/
    unsigned int fdd_tdd=(*para9)-1;
    unsigned int cmd_buf_fdd_tdd[2]={0,0};
    cmd_buf_fdd_tdd[0] = 0xF0220000|(42<<8);
    cmd_buf_fdd_tdd[1] = fdd_tdd;
    sendto(*pSendSocket, (char *)&cmd_buf_fdd_tdd, sizeof(cmd_buf_fdd_tdd),0,(SOCKADDR*)pRecvAddr, sizeof(sockaddr_in));
    /*trx_sw select*/
    unsigned int trx_sw=1;
    unsigned int cmd_buf_trx_sw[2]={0,0};
    cmd_buf_trx_sw[0] = 0xF0220000|(43<<8);
    cmd_buf_trx_sw[1] = trx_sw;
    sendto(*pSendSocket, (char *)&cmd_buf_trx_sw, sizeof(cmd_buf_trx_sw),0,(SOCKADDR*)pRecvAddr, sizeof(sockaddr_in));
    /*aux_dac1 setting*/
    unsigned int aux_dac1=0;
    unsigned int cmd_buf_aux_dac1[2]={0,0};
    cmd_buf_aux_dac1[0] = 0xF0220000|(44<<8);
    cmd_buf_aux_dac1[1] = aux_dac1;
    sendto(*pSendSocket, (char *)&cmd_buf_aux_dac1, sizeof(cmd_buf_aux_dac1),0,(SOCKADDR*)pRecvAddr, sizeof(sockaddr_in));
    /*handshake*/
    unsigned int cmd_buf_handshake[2]={0,0};
    cmd_buf_handshake[0] = 0xF0160001;
    sendto(*pSendSocket, (char *)&cmd_buf_handshake, sizeof(cmd_buf_handshake),0,(SOCKADDR*)pRecvAddr, sizeof(sockaddr_in));
    
}

void YunsdrCloseSocket(SimStruct *S)
{
    SOCKET *pSendSocketCmd = static_cast<SOCKET *>(ssGetPWork(S)[0]);
    sockaddr_in *pRecvAddrCmd = static_cast<sockaddr_in *>(ssGetPWork(S)[1]);
    SOCKET *pSendSocketData = static_cast<SOCKET *>(ssGetPWork(S)[2]);
    sockaddr_in *pRecvAddrData = static_cast<sockaddr_in *>(ssGetPWork(S)[3]);
    
    closesocket(*pSendSocketCmd);
    closesocket(*pSendSocketData);
    WSACleanup();
    delete pSendSocketCmd;
    pSendSocketCmd = NULL;
    delete pRecvAddrCmd;
    pRecvAddrCmd = NULL;
    delete pSendSocketData;
    pSendSocketData = NULL;
    delete pRecvAddrData;
    pRecvAddrData = NULL;    
    
}

// Required S-function trailer
#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
