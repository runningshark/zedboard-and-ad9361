/* Copyright 2003-2004 The MathWorks, Inc. */

// *******************************************************************
// **** To build this mex function use: mex sfun_cppcount_cpp.cpp ****
// *******************************************************************

#include <WINSOCK2.H>
#include <Windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <conio.h>
#include <math.h>
#include <pthread.h>

#pragma comment(lib,"x64/pthreadVC2.lib")
#pragma comment(lib,"ws2_32.lib")

#define S_FUNCTION_LEVEL 2
#define S_FUNCTION_NAME  YunSDR_receiver
// Need to include simstruc.h for the definition of the SimStruct and
// its associated macro definitions.
#include "simstruc.h"

#define OUTPUT_DATA_WIDTH    2048
#define RX_SAMPLES_NUM       (1024*8)
#define RING_BUFFER_MAXSIZE  8192*100

struct ring_buf
{
    unsigned char *data[RING_BUFFER_MAXSIZE];
    int front;
    int rear;
}*p;

static bool  runFlag = true;

pthread_t pid;
pthread_mutex_t runFlag_mutex = PTHREAD_MUTEX_INITIALIZER;

char RecvBuf[RX_SAMPLES_NUM]={0};
char *buf=RecvBuf;
int BufLen = RX_SAMPLES_NUM;

HANDLE event; 

void YunsdrStartSocket(SimStruct *S);
void YunsdrSendCmd(SimStruct *S);
static void *creat_recv_thread(void *arg);
void YunsdrCloseSocket(SimStruct *S);

#define IS_PARAM_DOUBLE(pVal) (mxIsNumeric(pVal) && !mxIsLogical(pVal) &&\
!mxIsEmpty(pVal) && !mxIsSparse(pVal) && !mxIsComplex(pVal) && mxIsDouble(pVal))
// Function: mdlInitializeSizes ===============================================
// Abstract:
//    The sizes information is used by Simulink to determine the S-function
//    block's characteristics (number of inputs, outputs, states, etc.).
static void mdlInitializeSizes(SimStruct *S)
{
    ssSetNumSFcnParams(S, 8);

    // Parameter mismatch will be reported by Simulink
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        return;
    }
    // Specify I/O
    if (!ssSetNumInputPorts(S, 0)) return;
    if (!ssSetNumOutputPorts(S,2)) return;
    ssSetOutputPortWidth(S, 0, OUTPUT_DATA_WIDTH);
    ssSetOutputPortWidth(S, 1, OUTPUT_DATA_WIDTH);
    ssSetNumSampleTimes(S, 1);
    ssSetNumPWork(S, 4);
    
}
// Function: mdlInitializeSampleTimes =========================================
// Abstract:
//   This function is used to specify the sample time(s) for your
//   S-function. You must register the same number of sample times as
//   specified in ssSetNumSampleTimes.
static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, -1);
    ssSetOffsetTime(S, 0, 0.0);
    ssSetModelReferenceSampleTimeDefaultInheritance(S); 
    
}
// Function: mdlStart =======================================================
// Abstract:
//   This function is called once at start of model execution. If you
//   have states that should be initialized once, this is the place
//   to do it.
#define MDL_START
static void mdlStart(SimStruct *S)
{ 
    p = (struct ring_buf *)malloc(sizeof(struct ring_buf));
    p->front = 0;
    p->rear = 0;
    int i;
    for(i = 0; i < RING_BUFFER_MAXSIZE; i++)
    {
        p->data[i] = (unsigned char *)malloc(RX_SAMPLES_NUM);
    }
    
    YunsdrStartSocket(S); 
    YunsdrSendCmd(S);
    event = CreateEvent(NULL, TRUE, TRUE, NULL);
    pthread_create(&pid, NULL, creat_recv_thread, S); 
    
}
// Function: mdlOutputs =======================================================
// Abstract:
//   In this function, you compute the outputs of your S-function
//   block.
static void mdlOutputs(SimStruct *S, int_T tid)
{
    char __buf[RX_SAMPLES_NUM]={0};
    char *Buf = __buf;
    
    real_T *signal_i = ssGetOutputPortRealSignal(S, 0);
    real_T *signal_q = ssGetOutputPortRealSignal(S, 1);
   
    WaitForSingleObject(event, INFINITE);
   
    memcpy(Buf, p->data[p->rear], RX_SAMPLES_NUM);
        p->rear = (p->rear + 1)%RING_BUFFER_MAXSIZE;
    if(p->rear == p->front)
        memcpy(Buf, __buf, RX_SAMPLES_NUM);
    
    signed short *sample = (signed short *)Buf;
    for(int i = 0; i<RX_SAMPLES_NUM/2; i=i+2)
    {
        signal_i[i/2] = sample[i];
        signal_q[i/2] = sample[i+1];
    }   
    
}
// Function: mdlTerminate =====================================================
// Abstract:
//   In this function, you should perform any actions that are necessary
//   at the termination of a simulation.  For example, if memory was
//   allocated in mdlStart, this is the place to free it.
static void mdlTerminate(SimStruct *S)
{
    YunsdrCloseSocket(S);
    runFlag = true;
}
/******************************************************************************/
/*user define function
/******************************************************************************/
void YunsdrStartSocket(SimStruct *S)
{
    real_T *para0 = mxGetPr(ssGetSFcnParam(S,0));
    real_T *para1 = mxGetPr(ssGetSFcnParam(S,1));
    real_T *para2 = mxGetPr(ssGetSFcnParam(S,2));
    
    WSADATA wsaCmd, wsaData;
    SOCKET *pSendSocketCmd = new SOCKET;
    SOCKET *pSendSocketData = new SOCKET;
    *pSendSocketCmd = INVALID_SOCKET;
    *pSendSocketData = INVALID_SOCKET;
    sockaddr_in *pRecvAddrCmd = new sockaddr_in;
    sockaddr_in *pRecvAddrData = new sockaddr_in;
    
    unsigned short PortCmd = *para1;
    unsigned short PortData = *para2;
    
    WSAStartup(MAKEWORD(2,2), &wsaCmd);
    WSAStartup(MAKEWORD(2,2), &wsaData);
    
    *pSendSocketCmd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    *pSendSocketData = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    
    pRecvAddrCmd->sin_family = AF_INET;
    pRecvAddrCmd->sin_port = htons(PortCmd);
    pRecvAddrCmd->sin_addr.s_addr = inet_addr("192.168.1.10");
    pRecvAddrData->sin_family = AF_INET;
    pRecvAddrData->sin_port = htons(PortData);
    pRecvAddrData->sin_addr.s_addr = inet_addr("192.168.1.10");
    
    ssSetPWorkValue(S, 0, pSendSocketCmd);
    ssSetPWorkValue(S, 1, pRecvAddrCmd);
    ssSetPWorkValue(S, 2, pSendSocketData);
    ssSetPWorkValue(S, 3, pRecvAddrData);
    
    connect(*pSendSocketData, (SOCKADDR*)pRecvAddrData, sizeof(sockaddr_in));
  
}

void YunsdrSendCmd(SimStruct *S)
{
    SOCKET *pSendSocketCmd = static_cast<SOCKET *>(ssGetPWork(S)[0]);
    sockaddr_in *pRecvAddrCmd = static_cast<sockaddr_in *>(ssGetPWork(S)[1]);
    /*rx_freq select*/ 
    real_T *para3 = mxGetPr(ssGetSFcnParam(S,3));
    unsigned double rx_freq=(*para3)*1e6;
    unsigned int cmd_buf_rx_freq[2] = {0,0};
    cmd_buf_rx_freq[0] = 0xF0220000|(15<<8)|(rx_freq>>32);
    cmd_buf_rx_freq[1] = (rx_freq)&0x00FFFFFFFFUL;
    sendto(*pSendSocketCmd, (char *)&cmd_buf_rx_freq, sizeof(cmd_buf_rx_freq),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));
    /*rx_bw select*/
    real_T *para4 = mxGetPr(ssGetSFcnParam(S,4));
    unsigned int bw=(*para4)*1e6;
    unsigned int cmd_buf_rx_bw[2]={0,0};
    cmd_buf_rx_bw[0] = 0xF0220000|(19<<8);
    cmd_buf_rx_bw[1] = bw;
    sendto(*pSendSocketCmd, (char *)&cmd_buf_rx_bw, sizeof(cmd_buf_rx_bw),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));
    /*rx_sample select*/
    real_T *para5 = mxGetPr(ssGetSFcnParam(S,5));
    unsigned long int sample_rate=(*para5)*1e6;
    unsigned int cmd_buf_rx_sample[2]={0,0};
    cmd_buf_rx_sample[0] = 0xF0220000|(17<<8);
    cmd_buf_rx_sample[1] = sample_rate;
    sendto(*pSendSocketCmd, (char *)&cmd_buf_rx_sample, sizeof(cmd_buf_rx_sample),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));/*rx_channel select*/
    /*rx_gain select*/
    real_T *para6 = mxGetPr(ssGetSFcnParam(S,6));
    long int gain=(*para6);
    unsigned int cmd_buf_chan1[2]={0,0};
    cmd_buf_chan1[0] = 0xF0220000 | (21<<8); 
    cmd_buf_chan1[1] = 0x0;
    sendto(*pSendSocketCmd, (char *)&cmd_buf_chan1, sizeof(cmd_buf_chan1),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));
    unsigned int cmd_buf_chan2[2]={0,0};
    cmd_buf_chan2[0] = 0xF0220000 | (23<<8);
    cmd_buf_chan2[1] = 0x0;
    sendto(*pSendSocketCmd, (char *)&cmd_buf_chan2, sizeof(cmd_buf_chan2),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));
    cmd_buf_chan1[0] = 0xF0220000 | (25<<8); 
    cmd_buf_chan1[1] = gain;  //set rx vga
    sendto(*pSendSocketCmd, (char *)&cmd_buf_chan1, sizeof(cmd_buf_chan1),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));
    cmd_buf_chan2[0] = 0xF0220000 | (27<<8);
    cmd_buf_chan2[1] = gain;  //set rx vga
    sendto(*pSendSocketCmd, (char *)&cmd_buf_chan2, sizeof(cmd_buf_chan2),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));
    /*rx_channel select*/
    real_T *para7 = mxGetPr(ssGetSFcnParam(S,7));
    unsigned int channel=*para7;
    unsigned int cmd_buf[2]={0,0};
    cmd_buf[0] = 0xF0210000|(channel&0x03);
    sendto(*pSendSocketCmd, (char *)&cmd_buf, sizeof(cmd_buf),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));
    /*ref select*/
    unsigned int ref_select=0;
    unsigned int cmd_buf_ref[2]={0,0};
    cmd_buf_ref[0] = 0xF0220000|(40<<8);
    cmd_buf_ref[1] = ref_select;
    sendto(*pSendSocketCmd, (char *)&cmd_buf_ref, sizeof(cmd_buf_ref),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));
    /*vco_cal_select*/
    unsigned int vco_cal=1;
    unsigned int cmd_buf_vco_cal[2]={0,0};
    cmd_buf_vco_cal[0] = 0xF0220000|(41<<8);
    cmd_buf_vco_cal[1] = vco_cal;
    sendto(*pSendSocketCmd, (char *)&cmd_buf_vco_cal, sizeof(cmd_buf_vco_cal),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));
    /*fdd or tdd select*/
    unsigned int fdd_tdd=1;
    unsigned int cmd_buf_fdd_tdd[2]={0,0};
    cmd_buf_fdd_tdd[0] = 0xF0220000|(42<<8);
    cmd_buf_fdd_tdd[1] = fdd_tdd;
    sendto(*pSendSocketCmd, (char *)&cmd_buf_fdd_tdd, sizeof(cmd_buf_fdd_tdd),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));
    /*trx_sw select*/
    unsigned int trx_sw=1;
    unsigned int cmd_buf_trx_sw[2]={0,0};
    cmd_buf_trx_sw[0] = 0xF0220000|(43<<8);
    cmd_buf_trx_sw[1] = trx_sw;
    sendto(*pSendSocketCmd, (char *)&cmd_buf_trx_sw, sizeof(cmd_buf_trx_sw),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));
    /*aux_dac1 setting*/
    unsigned int aux_dac1=0;
    unsigned int cmd_buf_aux_dac1[2]={0,0};
    cmd_buf_aux_dac1[0] = 0xF0220000|(44<<8);
    cmd_buf_aux_dac1[1] = aux_dac1;
    sendto(*pSendSocketCmd, (char *)&cmd_buf_aux_dac1, sizeof(cmd_buf_aux_dac1),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));
    /*rx_handshake*/
    unsigned int cmd_buf_handshake[2]={0,0};
    cmd_buf_handshake[0] = 0xF0160101;
    sendto(*pSendSocketCmd, (char *)&cmd_buf_handshake, sizeof(cmd_buf_handshake),0,(SOCKADDR*)pRecvAddrCmd, sizeof(sockaddr_in));
    
}

void *creat_recv_thread(void *arg)
{   
    SimStruct *S = (SimStruct *)arg;
    SOCKET *pSendSocketData = static_cast<SOCKET *>(ssGetPWork(S)[2]);
    pthread_mutex_lock(&runFlag_mutex);
    while(runFlag)
    {
        pthread_mutex_unlock(&runFlag_mutex);

        recv(*pSendSocketData, buf, BufLen,0);
        
        memcpy(p->data[p->front], buf, RX_SAMPLES_NUM);
        p->front = (p->front + 1)%RING_BUFFER_MAXSIZE;
        if((p->front +1) % RING_BUFFER_MAXSIZE == p->rear)
            memcpy(p->data[p->front], buf, RX_SAMPLES_NUM);
        
        SetEvent(event);
     } 
     pthread_mutex_unlock(&runFlag_mutex);
     
     return ((void *)0);
}

void YunsdrCloseSocket(SimStruct *S)
{
    runFlag = false;
    pthread_join(pid,NULL);
    
    int i = 0;
    for(i = 0; i < RING_BUFFER_MAXSIZE; i++)
    {
        free(p->data[i]);
        p->data[i] = NULL;
    }
    free(p);
    p = NULL;
    
    SOCKET *pSendSocketCmd = static_cast<SOCKET *>(ssGetPWork(S)[0]);
    sockaddr_in *pRecvAddrCmd = static_cast<sockaddr_in *>(ssGetPWork(S)[1]);
    SOCKET *pSendSocketData = static_cast<SOCKET *>(ssGetPWork(S)[2]);
    sockaddr_in *pRecvAddrData = static_cast<sockaddr_in *>(ssGetPWork(S)[3]);

    closesocket(*pSendSocketCmd);
    closesocket(*pSendSocketData);
    WSACleanup();
    delete pSendSocketCmd;
    pSendSocketCmd = NULL;
    delete pRecvAddrCmd;
    pRecvAddrCmd = NULL;
    delete pSendSocketData;
    pSendSocketData = NULL;
    delete pRecvAddrData;
    pRecvAddrData = NULL;
  
}

// Required S-function trailer
#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
