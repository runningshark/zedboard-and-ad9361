function   [dout,ang_offset]=phase_comp(din)
pilot=[din(9),din(18),din(27),din(36),din(45),din(54),din(63),din(72),...
       din(81),din(90),din(99),din(108),din(117),din(126),din(135),din(144)];
ang_offset=angle(sum((1-j)*pilot));
dout=din*exp(-j*ang_offset);
end

