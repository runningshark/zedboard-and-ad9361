function [ r_lowsamp ] = delete_pilot( r_data )
r_data=r_data';
r=[r_data(1:8),r_data(10:17),r_data(19:26),r_data(28:35),r_data(37:44),...
   r_data(46:53),r_data(55:62),r_data(64:71),r_data(73:80),...
   r_data(82:89),r_data(91:98),r_data(100:107),r_data(109:116),...
   r_data(118:125),r_data(127:134),r_data(136:143)];

r_lowsamp=[r,r_data(145:end)];
end

